/**
 * Utilitários de sanitização de scores e linhas de simulado.
 * Centraliza invariantes matemáticos para evitar dados impossíveis.
 */
import { pointsToPct } from './measurement.js';

export const SYNTHETIC_PERCENT_ONLY_TRIALS = 20;

/**
 * Retorna o total sintético para registros que têm apenas percentual.
 *
 * NOTA: O parâmetro `maxScore` é intencionalmente ignorado (prefixado com `_`).
 * O total sintético é sempre o número de tentativas sintéticas, não depende
 * da escala da prova. Isso é design intencional para manter consistência
 * entre diferentes escalas de prova.
 *
 * @param {number} _maxScore - Ignorado. Mantido para compatibilidade de API.
 * @param {Object} options - Opções. `syntheticTrials` override o número de tentativas.
 * @returns {number} Número de tentativas sintéticas.
 */
export function getSyntheticTotal(_maxScore = 100, options = {}) {
  const trials = Number(options?.syntheticTrials);
  return Number.isFinite(trials) && trials > 0 && trials <= 10000 ? trials : SYNTHETIC_PERCENT_ONLY_TRIALS;
}

export function isPercentOnlyRecord(row) {
  return (
    row &&
    Number.isFinite(Number(row.score)) &&
    (!Number.isFinite(Number(row.total)) || Number(row.total) <= 0)
  );
}

export function clamp(value, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, n));
}

export function toFiniteNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function toPoints(score, maxScore = 100, minScore = 0, mode = 'raw') {
  const safeMax = Number.isFinite(Number(maxScore)) && Number(maxScore) > 0 ? Number(maxScore) : 100;
  const safeMin = Number.isFinite(Number(minScore)) ? Number(minScore) : 0;
  const finalMin = Math.min(safeMin, safeMax);
  const finalMax = Math.max(safeMin, safeMax);
  const rawScore = Number(score);
  if (!Number.isFinite(rawScore)) return finalMin;

  if (mode === 'pct') {
    return clamp((rawScore / 100) * (finalMax - finalMin) + finalMin, finalMin, finalMax);
  }

  return clamp(rawScore, finalMin, finalMax);
}

export function toPct(score, maxScore = 100, minScore = 0) {
  const points = toPoints(score, maxScore, minScore, 'raw');
  return pointsToPct(points, maxScore, minScore);
}


export function formatValue(value, digits = 1) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '0';
  const safeDigits = Number.isFinite(Number(digits)) ? Math.max(0, Math.min(4, Number(digits))) : 1;
  return n.toLocaleString('pt-BR', {
    minimumFractionDigits: 0,
    maximumFractionDigits: safeDigits
  });
}

export function safeDisplayNumber(value, fallback = '—') {
  if (value === null || value === undefined || value === '' || typeof value === 'boolean') {
    return fallback;
  }
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function formatPercent(value, digits = 1) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '0%';
  return `${formatValue(n, digits)}%`;
}

export function normalizeScoreDomain(minScore, maxScore) {
  const isNil = (v) => v === null || v === undefined || v === '';
  const safeMin = !isNil(minScore) && Number.isFinite(Number(minScore)) ? Number(minScore) : 0;
  let safeMax = !isNil(maxScore) && Number.isFinite(Number(maxScore)) ? Number(maxScore) : 100;

  if (safeMax <= safeMin) {
    safeMax = safeMin + 1;
  }

  const range = Math.max(1e-9, safeMax - safeMin);

  const clamp = (value, fallback = safeMin) => {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(safeMin, Math.min(safeMax, n));
  };

  return { safeMin, safeMax, range, clamp };
}

export function normalizeProbability(value, fallback = 0) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.min(100, n));
}

export {
  clampFinite,
  safeDomain,
  sanitizeMaxScore,
  pointsToPct,
  pctToPoints,
  ratioToPoints,
  toProb01,
  toProbPct,
  safeDivide,
  safeTime,
  normalizeSubjectKey,
  sortChronologically,
  latestByDate,
  resolveTargetPoints,
  normalizeScoreValue,
  getSafeScore,
  clampCorrectToTotal,
  sanitizeSimuladoRow,
  mergeQuestionResult,
  deduplicateSimulados,
  buildSimuladoDateSubjectKeys,
  migrateContestData
} from "./measurement.js";


