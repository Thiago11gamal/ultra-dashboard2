import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generateAIQuestions } from '../../services/aiQuestionService';
import { useAppStore } from '../../store/useAppStore';
import { useToast } from '../../hooks/useToast';
import { getDateKey } from '../../utils/dateHelper';
import { generateId } from '../../utils/idGenerator';
import SimuladoSetup from './SimuladoSetup';
import SimuladoPlayer from './SimuladoPlayer';
import SimuladoResults from './SimuladoResults';
import ConfirmModal from '../ConfirmModal';
import { applyAIResultsToDraft } from '../../utils/aiSaveHelper';
import { safeGetJSON, markStorageDirty } from '../../utils/storageSafe';
import { safeDomain } from '../../utils/measurement';

const normalizeAlternative = (value) =>
  String(value ?? '').trim().toUpperCase();

const DIFFICULTIES = [
  { value: 'facil', label: 'Fácil' },
  { value: 'medio', label: 'Médio' },
  { value: 'dificil', label: 'Difícil' },
  { value: 'expert', label: 'Expert' },
];

const getAiSimStorageKey = () => {
  const activeId = useAppStore.getState().appState?.activeId || 'default';
  return `ai_simulado_draft:${activeId}`;
};

const getAiGenStorageKey = () => {
  const activeId = useAppStore.getState().appState?.activeId || 'default';
  return `ai_simulado_generating:${activeId}`;
};

const LOADING_MESSAGES = [
  "Iniciando Motor Analítico...",
  "Identificando Banca Examinadora...",
  "Cruzando Jurisprudências Recentes...",
  "Formulando Enunciados Inéditos...",
  "Calibrando Nível de Dificuldade...",
  "Ajustando Pegadinhas e Casos Práticos...",
  "Finalizando Pacote de Questões..."
];

// ✅ FIX C07: Usa crypto.randomUUID() quando disponível, eliminando o
// contador mutável que pode colidir após HMR (Hot Module Replacement).
// Fallback para Date.now() + random longo quando crypto não existe.
function nextAiId(prefix = 'ai') {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}-${crypto.randomUUID()}`;
  }
  // Fallback: timestamp de alta precisão + random duplo
  const time = (typeof performance !== 'undefined' && performance.now)
    ? performance.now().toString(36).replace('.', '')
    : '';
  const rand = () => Math.random().toString(36).substring(2, 11);
  return `${prefix}-${Date.now().toString(36)}-${time}-${rand()}${rand()}`;
}

export default function AIGeneratedSimulado() {
  const setData = useAppStore(state => state.setData);
  const categories = useAppStore(state => {
    const active = state.appState?.contests?.[state.appState?.activeId];
    const rawCategories = active?.categories || [];
    return Array.isArray(rawCategories) ? rawCategories : Object.values(rawCategories);
  });
  const showToast = useToast();

  const [step, setStep] = useState('setup');
  const [form, setForm] = useState({
    categoryId: '', taskId: '', materia: '', assunto: '',
    dificuldade: 'medio', quantidade: 10,
  });
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [timeLeft, setTimeLeft] = useState(45 * 60);
  const [timerActive, setTimerActive] = useState(false);
  const [showReview, setShowReview] = useState(false);
  const [loadingMsgIdx, setLoadingMsgIdx] = useState(0);
  const [timePerQuestion, setTimePerQuestion] = useState({});
  const [showEscapeConfirm, setShowEscapeConfirm] = useState(false);

  const mountedRef = useRef(true);
  const didMountRestoreRef = useRef(false);
  const abortControllerRef = useRef(null);
  const activeGenerationRef = useRef(null);

  const stepRef = useRef(step);
  const latestAnswersRef = useRef(answers);
  const latestQuestionsRef = useRef(questions);
  const latestFormRef = useRef(form);
  const isFinishingRef = useRef(false);
  const latestCurrentIndexRef = useRef(currentIndex);
  const latestTimePerQuestionRef = useRef(timePerQuestion);
  const latestTimeLeftRef = useRef(timeLeft);
  const simStartMsRef = useRef(null);

  useEffect(() => { stepRef.current = step; }, [step]);

  useEffect(() => {
    mountedRef.current = true;
    return () => { 
      mountedRef.current = false; 
      // G-20 FIX: Salvar draft imediatamente ao desmontar
      if (stepRef.current === 'playing' && latestQuestionsRef.current.length > 0) {
        try {
          const draft = {
            version: 1,
            form: latestFormRef.current,
            questions: latestQuestionsRef.current,
            answers: latestAnswersRef.current,
            currentIndex: latestCurrentIndexRef.current,
            timeLeft: latestTimeLeftRef.current,
            timePerQuestion: latestTimePerQuestionRef.current,
            simStartMs: simStartMsRef.current,
            savedAt: Date.now()
          };
          localStorage.setItem(getAiSimStorageKey(), JSON.stringify(draft));
        } catch (e) {
          console.warn('[Draft] Falha ao salvar no unmount:', e);
        }
      }
      // ✅ FIX: Abortar request pendente ao desmontar
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
        abortControllerRef.current = null;
      }
    };
  }, []);

  useEffect(() => { latestAnswersRef.current = answers; }, [answers]);
  useEffect(() => { latestQuestionsRef.current = questions; }, [questions]);
  useEffect(() => { latestFormRef.current = form; }, [form]);
  useEffect(() => { latestCurrentIndexRef.current = currentIndex; }, [currentIndex]);
  useEffect(() => { latestTimePerQuestionRef.current = timePerQuestion; }, [timePerQuestion]);
  useEffect(() => { latestTimeLeftRef.current = timeLeft; }, [timeLeft]);

  // FIX: Draft persist com debounce de 5s (não a cada segundo)
  const draftTimeoutRef = useRef(null);
  const timeLeftRef = useRef(timeLeft);
  useEffect(() => { timeLeftRef.current = timeLeft; }, [timeLeft]);

  useEffect(() => {
    if (step === 'playing' && questions.length > 0) {
      if (draftTimeoutRef.current) clearTimeout(draftTimeoutRef.current);
      draftTimeoutRef.current = setTimeout(() => {
        const draft = {
          version: 1,
          form, questions, answers, currentIndex,
          timeLeft: timeLeftRef.current,
          timePerQuestion, simStartMs: simStartMsRef.current, savedAt: Date.now()
        };
        try {
          localStorage.setItem(getAiSimStorageKey(), JSON.stringify(draft));
        } catch (e) {
          console.warn('[Draft] Storage full or unavailable:', e);
        }
      }, 5000);
    }
    return () => {
      if (draftTimeoutRef.current) clearTimeout(draftTimeoutRef.current);
    };
  }, [step, questions, answers, currentIndex, form]);

  // FIX: Effect de restore com deps vazias (ref já garante execução única)
  useEffect(() => {
    if (didMountRestoreRef.current) return;
    didMountRestoreRef.current = true;

    let timeoutId1;
    let timeoutId2;
    let cancelled = false;

    const gen = safeGetJSON(getAiGenStorageKey(), null);
    if (gen) {
      if (gen.status === 'done' && gen.questions?.length > 0) {
        timeoutId1 = setTimeout(() => {
          if (cancelled) return;
          
          const f = gen.form || {};
          setForm({
            categoryId: f.categoryId || '', taskId: f.taskId || '',
            materia: f.materia || '', assunto: f.assunto || '',
            dificuldade: f.dificuldade || 'medio', quantidade: f.quantidade || 10,
          });
          
          // ✅ FIX: Ler categories do store ATUAL, não da closure
          const currentCategories = useAppStore.getState().appState?.contests?.[
            useAppStore.getState().appState?.activeId
          ]?.categories || [];
          const catsArray = Array.isArray(currentCategories) 
            ? currentCategories 
            : Object.values(currentCategories);
          
          const cat = catsArray.find(c => c.id === f.categoryId);
          const tsk = cat?.tasks?.find(t => t.id === f.taskId);
          
          const normalizedQuestions = gen.questions.map((q) => ({
            ...q,
            id: q.id || nextAiId('ai-bg'),
            categoryId: f.categoryId, taskId: f.taskId,
            materia: cat?.name || f.materia,
            assunto: tsk ? (tsk.title || tsk.text || f.assunto) : f.assunto,
          }));
          
          isFinishingRef.current = false;
          setQuestions(normalizedQuestions);
          setAnswers({});
          setTimePerQuestion({});
          setCurrentIndex(0);
          setTimeLeft(normalizedQuestions.length * 3 * 60);
          setStep('playing');
          setTimerActive(true);
          simStartMsRef.current = Date.now();
          setShowReview(false);
          setIsLoading(false);
          localStorage.removeItem(getAiGenStorageKey());
          showToast(`${normalizedQuestions.length} questões geradas com sucesso!`, 'success');
        }, 0);
        return () => { cancelled = true; clearTimeout(timeoutId1); clearTimeout(timeoutId2); };
      } else if (gen.status === 'error') {
        timeoutId1 = setTimeout(() => {
          if (cancelled) return;
          showToast(gen.errorMessage || 'Erro ao gerar questões em segundo plano.', 'error');
          localStorage.removeItem(getAiGenStorageKey());
          setIsLoading(false);
        }, 0);
        return () => { cancelled = true; clearTimeout(timeoutId1); clearTimeout(timeoutId2); didMountRestoreRef.current = false; };
      } else if (gen.status === 'generating') {
        timeoutId1 = setTimeout(() => {
          if (cancelled) return;
          const f = gen.form || {};
          setForm({
            categoryId: f.categoryId || '', taskId: f.taskId || '',
            materia: f.materia || '', assunto: f.assunto || '',
            dificuldade: f.dificuldade || 'medio', quantidade: f.quantidade || 10,
          });
          setIsLoading(true);
          setStep('setup');
          if (activeGenerationRef.current) {
            activeGenerationRef.current.then((normalizedQuestions) => {
              if (cancelled || !mountedRef.current) return;
              if (normalizedQuestions && normalizedQuestions.length > 0) {
                isFinishingRef.current = false;
                setQuestions(normalizedQuestions);
                setAnswers({});
                setTimePerQuestion({});
                setCurrentIndex(0);
                setTimeLeft(normalizedQuestions.length * 3 * 60);
                setStep('playing');
                setTimerActive(true);
                simStartMsRef.current = Date.now();
                setIsLoading(false);
                localStorage.removeItem(getAiGenStorageKey());
                showToast(`${normalizedQuestions.length} questões geradas com sucesso!`, 'success');
              }
            }).catch((error) => {
              if (cancelled || !mountedRef.current) return;
              setIsLoading(false);
              localStorage.removeItem(getAiGenStorageKey());
              showToast(error.message || 'Erro ao gerar questões.', 'error');
            });
          } else {
            const age = Date.now() - (gen.startedAt || 0);
            localStorage.removeItem(getAiGenStorageKey());
            setIsLoading(false);
            if (age <= 5 * 60 * 1000) {
              showToast('A geração anterior foi interrompida. Gere novamente.', 'warning');
            }
          }
        }, 0);
        return () => { cancelled = true; clearTimeout(timeoutId1); clearTimeout(timeoutId2); didMountRestoreRef.current = false; };
      }
    }

    const draft = safeGetJSON(getAiSimStorageKey(), null);
    if (draft) {
      function isSimuladoDraftValid(d) {
        if (!d || typeof d !== 'object') return false;

        const draftVersion = Number(d.version ?? 1);
        if (!Number.isFinite(draftVersion) || draftVersion !== 1) return false;
        if (!Array.isArray(d.questions) || d.questions.length === 0) return false;
        const savedAt = Number(d.savedAt || 0);
        if (!Number.isFinite(savedAt) || savedAt <= 0) return false;
        const age = Date.now() - savedAt;
        return age >= 0 && age < 24 * 60 * 60 * 1000;
      }
      
      if (isSimuladoDraftValid(draft)) {
        timeoutId2 = setTimeout(() => {
          if (cancelled) return;
          
          const f = draft.form || {};
          let restoredForm = {
            categoryId: f.categoryId || '', taskId: f.taskId || '',
            materia: f.materia || '', assunto: f.assunto || '',
            dificuldade: f.dificuldade || 'medio', quantidade: f.quantidade || 10,
          };
          
          // ✅ FIX: Validar contra categories do store ATUAL
          const currentCategories = useAppStore.getState().appState?.contests?.[
            useAppStore.getState().appState?.activeId
          ]?.categories || [];
          const catsArray = Array.isArray(currentCategories) 
            ? currentCategories 
            : Object.values(currentCategories);
          
          // C-14 FIX: Validar que a categoria do draft existe no concurso ATUAL
          const cat = catsArray.find(c => c && c.id === f.categoryId);
          if (!cat && f.categoryId) {
            // Categoria não existe mais — descartar draft
            localStorage.removeItem(getAiSimStorageKey());
            localStorage.removeItem(getAiGenStorageKey());
            return;
          }
          const safeTasks = cat ? (Array.isArray(cat.tasks) ? cat.tasks : Object.values(cat.tasks || {})) : [];
          const tsk = safeTasks.find(t => t && t.id === f.taskId);
          
          if (restoredForm.taskId && !tsk) {
            restoredForm = { ...restoredForm, taskId: '', assunto: '' };
          }
          
          const questions = Array.isArray(draft.questions) ? draft.questions : [];
          const answers = Array.isArray(draft.answers) ? draft.answers : (draft.answers || {});
          const maxIndex = Math.max(0, questions.length - 1);
          const currentIndex = Number.isInteger(draft.currentIndex)
            ? Math.min(Math.max(draft.currentIndex, 0), maxIndex) : 0;
          const timeLeft = Number.isFinite(draft.timeLeft)
            ? Math.max(0, draft.timeLeft) : draft.questions.length * 3 * 60;
          
          const totalAllowedTime = questions.length * 3 * 60;
          const elapsedSeconds = Math.max(0, totalAllowedTime - timeLeft);

          setForm(restoredForm);
          setQuestions(questions);
          setAnswers(answers);
          setTimePerQuestion(draft.timePerQuestion || {});
          setCurrentIndex(currentIndex);
          setTimeLeft(timeLeft);
          setStep('playing');
          setTimerActive(true);

          simStartMsRef.current = Number.isFinite(Number(draft.simStartMs))
            ? Number(draft.simStartMs)
            : Date.now() - elapsedSeconds * 1000;
        }, 0);
      }
    }

    return () => {
      cancelled = true;
      clearTimeout(timeoutId1);
      clearTimeout(timeoutId2);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // FIX: deps vazias — ref garante execução única

  const handleInputChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleCategorySelect = (catId) => {
    const cat = categories.find(c => c.id === catId);
    setForm(prev => ({
      ...prev, categoryId: catId || '', materia: cat ? cat.name : '',
      taskId: '', assunto: '',
    }));
  };

  const handleTaskSelect = (tskId) => {
    const cat = categories.find(c => c.id === form.categoryId);
    const rawCatTasks = cat?.tasks || [];
    const safeCatTasks = Array.isArray(rawCatTasks) ? rawCatTasks : Object.values(rawCatTasks);
    const tsk = safeCatTasks.find(t => t.id === tskId);
    setForm(prev => ({
      ...prev, taskId: tskId || '',
      assunto: tsk ? (tsk.title || tsk.text || '') : '',
    }));
  };

  const selectedCategory = categories.find(c => c.id === form.categoryId);
  const rawTasks = selectedCategory?.tasks || [];
  const availableTasks = Array.isArray(rawTasks) ? rawTasks : Object.values(rawTasks);

  const generatePersonalizedSimulado = async () => {
    const allTasks = [];
    categories.forEach(cat => {
      const stats = cat.simuladoStats;
      const level = stats?.level || 'BAIXO';
      const avg = stats?.average || 0;
      const catTasksRaw = cat.tasks || [];
      const safeCatTasks = Array.isArray(catTasksRaw) ? catTasksRaw : Object.values(catTasksRaw);
      safeCatTasks.forEach(tsk => {
        const title = String(tsk.title || tsk.text || '').trim();
        if (title) {
          allTasks.push({ catId: cat.id, taskId: tsk.id, materia: cat.name, assunto: title, level, avg });
        }
      });
    });
    const levelScore = { 'BAIXO': 1, 'MÉDIO': 2, 'ALTO': 3 };
    allTasks.sort((a, b) => {
      const lsA = levelScore[a.level] || 1;
      const lsB = levelScore[b.level] || 1;
      if (lsA !== lsB) return lsA - lsB;
      return a.avg - b.avg;
    });
    const worstTasks = allTasks.slice(0, 5);
    if (worstTasks.length === 0) {
      showToast('Cadastre matérias e assuntos no Dashboard primeiro.', 'warning');
      return;
    }
    const assuntoString = worstTasks.map(t => `- Matéria: ${t.materia} | Assunto: ${t.assunto} (Nível: ${t.level})`).join('\n');
    const avgDifficulty = worstTasks.reduce((acc, t) => acc + (levelScore[t.level] || 1), 0) / worstTasks.length;
    let adaptiveDifficulty = 'medio';
    if (avgDifficulty >= 2.5) adaptiveDifficulty = 'expert';
    else if (avgDifficulty >= 1.5) adaptiveDifficulty = 'dificil';

    setForm(prev => ({
      ...prev, categoryId: 'mixed', taskId: 'mixed',
      materia: 'Simulado Personalizado', assunto: assuntoString,
      dificuldade: adaptiveDifficulty, quantidade: 10
    }));
    setIsLoading(true);

    const genForm = { categoryId: 'mixed', taskId: 'mixed', materia: 'Simulado Personalizado', assunto: assuntoString, dificuldade: adaptiveDifficulty, quantidade: 10 };
    const genState = { status: 'generating', form: genForm, startedAt: Date.now() };
    localStorage.setItem(getAiGenStorageKey(), JSON.stringify(genState));
    const activeContestName = useAppStore.getState().appState?.contests?.[useAppStore.getState().appState?.activeId]?.name || 'Concurso Geral';

    // FIX: Usar ref em vez de variável de módulo
    // ✅ FIX: Criar AbortController para esta geração
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();
    const signal = abortControllerRef.current.signal;

    const localPromise = (async () => {
      try {
        const generated = await generateAIQuestions({
          materia: 'Simulado Personalizado', assunto: assuntoString,
          dificuldade: adaptiveDifficulty, quantidade: 10, contestName: activeContestName,
          signal,
        });

        // ✅ FIX: Verificar se foi abortado antes de processar
        if (signal.aborted) return null;

        if (!Array.isArray(generated) || generated.length === 0) {
          throw new Error('A IA não gerou questões válidas.');
        }
        const normalizedQuestions = generated.map((q) => ({
          ...q, id: q.id || nextAiId('ai-pers'), categoryId: 'mixed', taskId: 'mixed',
        }));
        localStorage.setItem(getAiGenStorageKey(), JSON.stringify({
          status: 'done', form: genForm, questions: normalizedQuestions, completedAt: Date.now(),
        }));
        return normalizedQuestions;
      } catch (err) {
        if (signal.aborted) return null; // ✅ FIX: Ignorar erros de abort
        localStorage.setItem(getAiGenStorageKey(), JSON.stringify({
          status: 'error', errorMessage: err.message,
        }));
        return null;
      }
    })();
    activeGenerationRef.current = localPromise;

    try {
      const normalizedQuestions = await localPromise;
      if (activeGenerationRef.current === localPromise) {
        activeGenerationRef.current = null;
      }
      if (!mountedRef.current) return;
      if (normalizedQuestions && normalizedQuestions.length > 0) {
        isFinishingRef.current = false;
        setQuestions(normalizedQuestions);
        setAnswers({});
        setTimePerQuestion({});
        setCurrentIndex(0);
        setTimeLeft(normalizedQuestions.length * 3 * 60);
        setStep('playing');
        setTimerActive(true);
        simStartMsRef.current = Date.now();
        setShowReview(false);
        setIsLoading(false);
        localStorage.removeItem(getAiGenStorageKey());
        showToast(`Personalizado: ${normalizedQuestions.length} questões focadas nas fraquezas!`, 'success');
      }
    } catch (error) {
      if (activeGenerationRef.current === localPromise) {
        activeGenerationRef.current = null;
      }
      if (!mountedRef.current) return;
      setIsLoading(false);
      localStorage.removeItem(getAiGenStorageKey());
      showToast(error.message || 'Erro ao gerar questões personalizadas.', 'error');
    }
  };

  const handleGenerate = async () => {
    if (!form.categoryId || !form.taskId) {
      showToast('Selecione Matéria e Assunto cadastrados', 'error');
      return;
    }
    setIsLoading(true);
    const genState = { status: 'generating', form: { ...form }, startedAt: Date.now() };
    localStorage.setItem(getAiGenStorageKey(), JSON.stringify(genState));
    const currentForm = { ...form };
    const currentCategories = [...categories];
    const activeContestName = useAppStore.getState().appState?.contests?.[useAppStore.getState().appState?.activeId]?.name || 'Concurso Geral';

    // FIX: Usar ref em vez de variável de módulo
    // ✅ FIX: Criar AbortController para esta geração
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();
    const signal = abortControllerRef.current.signal;

    const localPromise = (async () => {
      try {
        const generated = await generateAIQuestions({
          materia: currentForm.materia.trim(), assunto: currentForm.assunto.trim(),
          dificuldade: currentForm.dificuldade, quantidade: currentForm.quantidade,
          contestName: activeContestName,
          signal,
        });

        // ✅ FIX: Verificar se foi abortado antes de processar
        if (signal.aborted) return null;

        if (!Array.isArray(generated) || generated.length === 0) {
          throw new Error('A IA não gerou questões válidas.');
        }
        const cat = currentCategories.find(c => c.id === currentForm.categoryId);
        const rawGenTasks = cat?.tasks || [];
        const safeGenTasks = Array.isArray(rawGenTasks) ? rawGenTasks : Object.values(rawGenTasks);
        const tsk = safeGenTasks.find(t => t.id === currentForm.taskId);
        const normalizedQuestions = generated.map((q) => ({
          ...q, id: q.id || nextAiId('ai-gen'),
          categoryId: currentForm.categoryId, taskId: currentForm.taskId,
          materia: cat?.name || currentForm.materia,
          assunto: tsk ? (tsk.title || tsk.text || currentForm.assunto) : currentForm.assunto,
        }));
        localStorage.setItem(getAiGenStorageKey(), JSON.stringify({
          status: 'done', form: currentForm, questions: normalizedQuestions, completedAt: Date.now(),
        }));
        return normalizedQuestions;
      } catch (error) {
        if (signal.aborted) return null; // ✅ FIX: Ignorar erros de abort
        localStorage.setItem(getAiGenStorageKey(), JSON.stringify({
          status: 'error', form: currentForm, errorMessage: error.message || 'Erro ao gerar questões com IA.', failedAt: Date.now(),
        }));
        throw error;
      }
    })();
    activeGenerationRef.current = localPromise;

    try {
      const normalizedQuestions = await localPromise;
      if (activeGenerationRef.current === localPromise) {
        activeGenerationRef.current = null;
      }
      if (!mountedRef.current || !normalizedQuestions) return;
      isFinishingRef.current = false;
      setQuestions(normalizedQuestions);
      setAnswers({});
      setTimePerQuestion({});
      setCurrentIndex(0);
      setTimeLeft(normalizedQuestions.length * 3 * 60);
      setStep('playing');
      setTimerActive(true);
      simStartMsRef.current = Date.now();
      localStorage.removeItem(getAiGenStorageKey());
      showToast(`${normalizedQuestions.length} questões geradas com sucesso!`, 'success');
    } catch (error) {
      if (activeGenerationRef.current === localPromise) {
        activeGenerationRef.current = null;
      }
      if (!mountedRef.current) return;
      console.error('Erro na geração IA:', error);
      showToast(error.message || 'Erro ao gerar questões com IA. Tente novamente.', 'error');
      localStorage.removeItem(getAiGenStorageKey());
    } finally {
      if (mountedRef.current) setIsLoading(false);
    }
  };

  const currentQuestion = questions[currentIndex];

  const selectAnswer = useCallback((letra) => {
    if (!currentQuestion) return;
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: letra }));
  }, [currentQuestion]);

  const goTo = useCallback((index) => {
    const qLen = latestQuestionsRef.current.length || questions.length;
    if (index >= 0 && index < qLen) {
      setCurrentIndex(index);
    }
  }, [questions.length]);

  const saveAIResultsToSystem = useCallback(async (formData, correct, total, _answeredQs, timeSpentSecs = 0, preventGlobalEvent = false, batchId = null) => {
    // FIX: mutação atômica síncrona, desliga temporariamente os subscribers se preventGlobalEvent for true
    useAppStore.setState(
        (state) => {
            const nextContests = { ...state.appState.contests };
            const draft = nextContests[state.appState.activeId];
            if (!draft) return state;
            applyAIResultsToDraft(draft, formData, correct, total, timeSpentSecs, preventGlobalEvent, batchId);
            return {
                appState: {
                    ...state.appState,
                    version: (state.appState.version || 0) + 1,
                    contests: nextContests,
                    lastUpdated: new Date().toISOString()
                }
            };
        },
        false, 
        preventGlobalEvent ? "AI_BACKGROUND_SAVE" : "AI_SIMULADO_SAVE"
    );
    markStorageDirty();
  }, []);

  const handleFinish = useCallback(async () => {
    const qList = latestQuestionsRef.current.length > 0 ? latestQuestionsRef.current : questions;
    const ansMap = Object.keys(latestAnswersRef.current).length > 0 ? latestAnswersRef.current : answers;
    const f = latestFormRef.current;
    if (qList.length === 0) {
      showToast('Nenhuma questão disponível para finalizar.', 'warning');
      return;
    }

    // FIX: Garantir que latestTimePerQuestionRef está sincronizado
    const timePerQ = latestTimePerQuestionRef.current || timePerQuestion || {};

    const absoluteElapsedSecs = simStartMsRef.current ? Math.round((Date.now() - simStartMsRef.current) / 1000) : 0;
    const totalAllowedTime = qList.length * 3 * 60;
    const fallbackTimeSpent = Math.max(absoluteElapsedSecs, totalAllowedTime - latestTimeLeftRef.current);

    if (isFinishingRef.current || stepRef.current === 'finished') return;
    isFinishingRef.current = true;

    try {
      let correctCount = 0;
      const answeredQuestions = [];
    qList.forEach(q => {
      const selected = ansMap[q.id];
      const wasAnswered = selected !== undefined && selected !== null;
      const isCorrect =
        wasAnswered &&
        normalizeAlternative(selected) === normalizeAlternative(q.alternativa_correta);
      if (isCorrect) correctCount++;
      answeredQuestions.push({ ...q, selected: selected || null, isCorrect, wasAnswered });
    });

    const total = qList.length;
    const scorePercent = total > 0 ? Math.round((correctCount / total) * 100) : 0;
    const exactTotalTime = answeredQuestions.reduce((acc, q) => acc + (timePerQ[q.id] || 0), 0);
    const finalTimeSpent = exactTotalTime > 0 ? exactTotalTime : fallbackTimeSpent;
    const sessionBatchId = generateId('batch');

    if (f.categoryId === 'mixed') {
      const groups = {};
      answeredQuestions.forEach(q => {
        const key = `${q.materia}\u0000${q.assunto}`;
        if (!groups[key]) groups[key] = { materia: q.materia, assunto: q.assunto, correct: 0, total: 0, qs: [], timeSpent: 0 };
        groups[key].qs.push(q);
        groups[key].total++;
        if (q.isCorrect) groups[key].correct++;
        const spent = timePerQ[q.id] || 0;
        groups[key].timeSpent += spent;
      });
      const rawCats = useAppStore.getState().appState?.contests?.[useAppStore.getState().appState?.activeId]?.categories || [];
      const cats = Array.isArray(rawCats) ? rawCats : Object.values(rawCats);
      const totalQuestionsInMixed = Object.values(groups).reduce((acc, g) => acc + g.total, 0);
      const totalCorrectInMixed = Object.values(groups).reduce((acc, g) => acc + g.correct, 0);

      const failedGroups = [];
      const promises = Object.entries(groups).map(async ([groupKey, g]) => {
        try {
            const [materia, assunto] = groupKey.split('\u0000');

            const cat = cats.find(c =>
              String(c?.name || '').trim().toLowerCase() === String(materia || '').trim().toLowerCase()
            );

            const catTasks = cat?.tasks ? (Array.isArray(cat.tasks) ? cat.tasks : Object.values(cat.tasks)) : [];
            const tsk = catTasks.find(t =>
              String(t?.title || t?.text || '').trim().toLowerCase() === String(assunto || '').trim().toLowerCase()
            );

            const subForm = {
              ...f, materia: g.materia, assunto: g.assunto,
              categoryId: cat ? cat.id : null, taskId: tsk ? tsk.id : null,
            };
            const topicTime =
              g.timeSpent > 0
                ? g.timeSpent
                : Math.round(fallbackTimeSpent * (g.total / Math.max(1, totalQuestionsInMixed)));
            await saveAIResultsToSystem(subForm, g.correct, g.total, g.qs, topicTime, true, sessionBatchId);
        } catch (err) {
            console.error(`[AI Sim] Falha ao salvar grupo ${groupKey}:`, err);
            failedGroups.push(groupKey);
        }
      });
      await Promise.allSettled(promises);
      
      if (failedGroups.length > 0) {
          showToast(`⚠️ ${failedGroups.length} grupo(s) não salvos: ${failedGroups.join(', ')}`, 'warning');
      }

      const nowIso = new Date().toISOString();
      const todayKey = getDateKey(new Date()) || new Date().toISOString().slice(0, 10);
      const activeContest = useAppStore.getState().appState?.contests?.[useAppStore.getState().appState?.activeId];
      const mixedDomain = safeDomain(Number(activeContest?.maxScore) || 100, Number(activeContest?.minScore) || 0);
      const mixedRatio = totalQuestionsInMixed > 0 ? totalCorrectInMixed / totalQuestionsInMixed : 0;
      const mixedScorePoints = mixedDomain.min + mixedRatio * mixedDomain.range;
      const mixedScorePct = mixedRatio * 100;
      const globalMixedEvent = {
        id: generateId('ai-sim'),
        batchId: sessionBatchId,
        date: todayKey,
        createdAt: nowIso,
        lastUpdated: nowIso,
        scorePoints: mixedScorePoints,
        scorePct: mixedScorePct,
        score: mixedScorePoints,
        total: totalQuestionsInMixed,
        correct: totalCorrectInMixed,
        type: 'ai-simulado',
        subject: 'Simulado Misto (IA)',
        categoryId: 'mixed',
        taskId: null,
        validated: true,
        scoreUnit: 'points',
        isPercentage: false,
      };
      useAppStore.setState(
        (state) => {
          const nextContests = { ...state.appState.contests };
          const draft = nextContests[state.appState.activeId];
          if (!draft) return state;
          const existingSims = Array.isArray(draft.simulados) ? draft.simulados : [];
          draft.simulados = [...existingSims, globalMixedEvent].slice(-100);
          draft.lastUpdated = new Date().toISOString();
          return {
            appState: {
              ...state.appState,
              version: (state.appState.version || 0) + 1,
              contests: nextContests,
              lastUpdated: new Date().toISOString()
            }
          };
        },
        false,
        "AI_MIXED_SIMULADO_SAVE"
      );
      markStorageDirty();
    } else {
      await saveAIResultsToSystem(f, correctCount, total, answeredQuestions, finalTimeSpent, false, sessionBatchId);
    }

      setResults({
        correct: correctCount, total, scorePercent,
        questions: answeredQuestions, timeSpentSecs: finalTimeSpent,
      });
      setStep('finished');
      setTimerActive(false);
      localStorage.removeItem(getAiSimStorageKey());
      showToast(`Simulado finalizado! ${correctCount}/${total} acertos`, 'success');
    } catch (error) {
      console.error('[Simulado] Error finishing:', error);
      showToast('Erro ao finalizar o simulado.', 'error');
      isFinishingRef.current = false;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saveAIResultsToSystem, showToast, setData]);

  const finishMutexRef = useRef(false);

  const safeFinish = useCallback(async () => {
    if (finishMutexRef.current) return;
    finishMutexRef.current = true;
    try {
      await handleFinish();
    } finally {
      setTimeout(() => { finishMutexRef.current = false; }, 1000);
    }
  }, [handleFinish]);

  const safeFinishRef = useRef(safeFinish);
  useEffect(() => { safeFinishRef.current = safeFinish; }, [safeFinish]);

  const activeQIdRef = useRef(null);
  useEffect(() => { activeQIdRef.current = questions[currentIndex]?.id; }, [currentIndex, questions]);

  useEffect(() => {
    if (!timerActive || step !== 'playing') return;

    let lastTick = Date.now();

    const interval = setInterval(() => {
      const now = Date.now();
      const elapsedSecs = Math.round((now - lastTick) / 1000);
      lastTick = now;

      if (elapsedSecs > 0) {
        setTimeLeft((prev) => {
           const next = prev - elapsedSecs;
           return next <= 0 ? 0 : next;
        });
        
        const qId = activeQIdRef.current;
        if (qId) {
          setTimePerQuestion(prev => ({ ...prev, [qId]: (prev[qId] || 0) + elapsedSecs }));
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [timerActive, step]);

  useEffect(() => {
    if (step !== 'playing') return;
    if (!timerActive) return;
    if (timeLeft > 0) return;
    if (isFinishingRef.current) return;

    safeFinishRef.current();
  }, [step, timerActive, timeLeft]);

  const resetAll = useCallback(() => {
    isFinishingRef.current = false;
    setStep('setup');
    setQuestions([]);
    setAnswers({});
    setTimePerQuestion({});
    setCurrentIndex(0);
    setResults(null);
    setTimeLeft(Math.max(1, Number(form.quantidade) || 10) * 3 * 60);
    setTimerActive(false);
    setShowReview(false);
    localStorage.removeItem(getAiSimStorageKey());
  }, [form.quantidade]);

  const retrySameQuestions = () => {
    isFinishingRef.current = false;
    setAnswers({});
    setTimePerQuestion({});
    setCurrentIndex(0);
    setResults(null);
    setTimeLeft(questions.length * 3 * 60);
    setTimerActive(true);
    setShowReview(false);
    setStep('playing');

    simStartMsRef.current = Date.now();

    showToast('Questões reiniciadas. Boa sorte!', 'info');
  };

  useEffect(() => {
    if (step !== 'playing' || !currentQuestion) return;
    const handleKeyDown = (e) => {
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT')) {
        return;
      }
      const key = e.key.toUpperCase();
      const curIdx = latestCurrentIndexRef.current;
      const qLen = latestQuestionsRef.current.length || questions.length;
      if (['A', 'B', 'C', 'D', 'E'].includes(key)) { e.preventDefault(); selectAnswer(key); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); goTo(curIdx - 1); }
      else if (e.key === 'ArrowRight' || e.key === 'Enter') {
        e.preventDefault();
        if (curIdx < qLen - 1) goTo(curIdx + 1); else safeFinishRef.current();
      } else if (e.key.toLowerCase() === 'escape') {
        e.preventDefault();
        setShowEscapeConfirm(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
     
  }, [step, currentQuestion, questions.length, goTo, selectAnswer, resetAll]);

  useEffect(() => {
    let interval = null;
    let timeout = null;
    if (isLoading) {
      interval = setInterval(() => {
        setLoadingMsgIdx(prev => (prev < LOADING_MESSAGES.length - 1 ? prev + 1 : prev));
      }, 3500);
    } else {
      timeout = setTimeout(() => setLoadingMsgIdx(0), 0);
    }
    return () => {
      if (interval) clearInterval(interval);
      if (timeout) clearTimeout(timeout);
    };
  }, [isLoading]);

  if (step === 'setup') {
    return (
      <SimuladoSetup
        form={form} handleInputChange={handleInputChange} categories={categories}
        handleCategorySelect={handleCategorySelect} handleTaskSelect={handleTaskSelect}
        availableTasks={availableTasks} generatePersonalizedSimulado={generatePersonalizedSimulado}
        handleGenerate={handleGenerate} isLoading={isLoading} loadingMsgIdx={loadingMsgIdx}
        DIFFICULTIES={DIFFICULTIES} LOADING_MESSAGES={LOADING_MESSAGES}
      />
    );
  }
  if (step === 'playing' && currentQuestion) {
    return (
      <>
        <SimuladoPlayer
          form={form} questions={questions} currentIndex={currentIndex} answers={answers}
          timeLeft={timeLeft} DIFFICULTIES={DIFFICULTIES} goTo={goTo} selectAnswer={selectAnswer}
          handleFinish={safeFinish} resetAll={() => setShowEscapeConfirm(true)}
        />
        <ConfirmModal
          isOpen={showEscapeConfirm}
          onClose={() => setShowEscapeConfirm(false)}
          onConfirm={() => { setShowEscapeConfirm(false); resetAll(); }}
          title="Sair do Simulado"
          message="Tem certeza que deseja sair? Todo o progresso deste simulado será perdido."
          confirmText="Sair e Descartar"
          type="danger"
        />
      </>
    );
  }
  if (step === 'finished' && results) {
    return (
      <SimuladoResults
        results={results} form={form} showReview={showReview} setShowReview={setShowReview}
        resetAll={resetAll} retrySameQuestions={retrySameQuestions} showToast={showToast}
      />
    );
  }
  return (
    <div className="flex flex-col items-center justify-center min-h-[300px] gap-4 p-8 text-center bg-slate-900/60 rounded-2xl border border-white/5 mx-auto">
      <p className="text-sm text-slate-400">Nenhuma questão ativa ou estado de simulado divergente.</p>
      <button
        onClick={resetAll}
        className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-bold text-white text-sm transition-colors"
      >
        Voltar ao início
      </button>
    </div>
  );
}

