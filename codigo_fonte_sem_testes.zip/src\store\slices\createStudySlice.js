import { generateId } from '../../utils/idGenerator.js';
import { XP_CONFIG } from '../../config/gamification.js';
import { SYNC_LOG_CAP } from '../../config.js';
import { markStorageDirty } from '../../utils/storageSafe.js';

const LOG_CAP = SYNC_LOG_CAP;
const SESSION_CAP = SYNC_LOG_CAP;

export const createStudySlice = (set, get) => ({
  handleUpdateStudyTime: (categoryId, minutes, taskId) => {
    const rawMinutes = Number(minutes);
    if (!Number.isFinite(rawMinutes) || rawMinutes <= 0) {
      console.warn('[StudySlice] minutes inválido, ignorando:', minutes);
      return;
    }
    const safeMinutes = Math.min(1440, Math.max(0.1, rawMinutes));

    let pendingXp = 0;

    set((state) => {
      const now = new Date().toISOString();
      const activeData = state.appState.contests[state.appState.activeId];

      if (!activeData) return;

      const logId = generateId('log');
      const sessionId = generateId('session');

      const category = activeData?.categories?.find(c => c.id === categoryId);

      let taskTitle = '';

      if (category && taskId) {
        const task = (category.tasks || []).find(
          t => t.id === taskId || t.text === taskId || t.title === taskId
        );

        taskTitle = task?.title || task?.text || (String(taskId).startsWith('task') ? '' : taskId);
      }

      const newLog = {
        id: logId,
        date: now,
        categoryId,
        taskId,
        minutes: safeMinutes,
        taskTitle
      };

      const xpPerMinute = (XP_CONFIG.pomodoro.base / 25) || 1;
      const baseXP = Math.floor(safeMinutes * xpPerMinute);
      const bonusXP = taskId ? (XP_CONFIG.pomodoro.bonusWithTask || 5) : 0;
      pendingXp = baseXP + bonusXP;

      const newSession = {
        id: sessionId,
        startTime: now,
        duration: safeMinutes,
        categoryId,
        taskId,
        taskTitle,
        logReferenceId: logId,
        awardedXP: pendingXp // ✅ FIX: Guarda o recibo exato de XP concedido
      };

      const safeLogs = Array.isArray(activeData.studyLogs)
        ? activeData.studyLogs
        : Object.values(activeData.studyLogs || {});

      const safeSessions = Array.isArray(activeData.studySessions)
        ? activeData.studySessions
        : Object.values(activeData.studySessions || {});

      activeData.studyLogs = [...safeLogs, newLog].slice(-LOG_CAP);
      activeData.studySessions = [...safeSessions, newSession].slice(-SESSION_CAP);

      if (category) {
        category.totalMinutes = (category.totalMinutes || 0) + safeMinutes;
        category.lastStudiedAt = now;

        if (taskId) {
          const task = (category.tasks || []).find(t => t.id === taskId);
          if (task) task.lastStudiedAt = now;
        }
      }
      
      const startHour = new Date(now).getHours();
      if (activeData.user) {
        if (startHour >= 4 && startHour < 7) activeData.user.studiedEarly = true;
        if (startHour >= 23 || startHour < 4) activeData.user.studiedLate = true;
      }

      state.appState.version = (state.appState.version || 0) + 1;
      state.appState.lastUpdated = new Date().toISOString();
      markStorageDirty();
    });

    if (pendingXp > 0 && typeof get().awardExperience === 'function') {
      get().awardExperience(pendingXp);
    }
  },

  deleteSession: (sessionId) => {
    let xpToDeduct = 0;

    set((state) => {
      const activeData = state.appState.contests[state.appState.activeId];

      if (!activeData) return;

      const safeSessions = Array.isArray(activeData.studySessions)
        ? activeData.studySessions
        : Object.values(activeData.studySessions || {});

      const sessionIndex = safeSessions.findIndex(s => s.id === sessionId);
      if (sessionIndex === -1) return;

      const session = safeSessions[sessionIndex];

      // ✅ FIX: Usar recibo de XP (awardedXP) se existir, senão recalcular (para dados legados)
      if (Number.isFinite(session.awardedXP)) {
        xpToDeduct = session.awardedXP;
      } else {
        const xpPerMinute = (XP_CONFIG.pomodoro.base / 25) || 1;
        const baseXP = Math.floor((session.duration || 0) * xpPerMinute);
        const bonusXP = session.taskId ? (XP_CONFIG.pomodoro.bonusWithTask || 5) : 0;
        xpToDeduct = baseXP + bonusXP;
      }

      const category = (activeData.categories || []).find(c => c.id === session.categoryId);

      if (category) {
        category.totalMinutes = Math.max(0, (category.totalMinutes || 0) - (session.duration || 0));
      }

      safeSessions.splice(sessionIndex, 1);
      activeData.studySessions = safeSessions;

      if (activeData.studyLogs) {
        const safeLogs = Array.isArray(activeData.studyLogs)
          ? activeData.studyLogs
          : Object.values(activeData.studyLogs || {});

        if (session.logReferenceId) {
          activeData.studyLogs = safeLogs.filter(l => l.id !== session.logReferenceId);
        } else {
          activeData.studyLogs = safeLogs.filter(l => l.id !== session.id);
        }
      }

      state.appState.version = (state.appState.version || 0) + 1;
      state.appState.lastUpdated = new Date().toISOString();
      markStorageDirty();
    });

    if (xpToDeduct > 0 && typeof get().awardExperience === 'function') {
      get().awardExperience(-xpToDeduct);
    }
  },

  logFlashcardReview: (deckId, cardId, rating, subject, minutes = 0.5) => {
    set((state) => {
      const activeData = state.appState.contests[state.appState.activeId];
      if (!activeData) return;

      const now = new Date().toISOString();
      const logId = generateId('flashlog');

      let categoryId = null;
      const normCatName = (name) => (name || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
      const normSubject = normCatName(subject);

      const catsArray = Array.isArray(activeData.categories)
        ? activeData.categories
        : Object.values(activeData.categories || {});

      if (catsArray.length > 0 && normSubject) {
        const exactMatch = catsArray.find(c =>
          c && normCatName(c.name) === normSubject
        );
        const match = exactMatch || catsArray.find(c => {
          if (!c) return false;
          const catNorm = normCatName(c.name);
          return catNorm.startsWith(normSubject);
        });

        if (match) categoryId = match.id;
      }

      const isCorrect = rating >= 2;

      const newLog = {
        id: logId,
        date: now,
        categoryId: categoryId || null,
        taskId: deckId,
        minutes,
        taskTitle: 'Revisão de Flashcard',
        type: 'flashcard',
        deckId,
        cardId,
        rating,
        correct: isCorrect
      };

      const safeLogs = Array.isArray(activeData.studyLogs)
        ? activeData.studyLogs
        : Object.values(activeData.studyLogs || {});

      activeData.studyLogs = [...safeLogs, newLog].slice(-LOG_CAP);

      if (categoryId) {
        const cat = activeData.categories.find(c => c.id === categoryId);

        if (cat) {
          cat.flashcardReviews = (cat.flashcardReviews || 0) + 1;
          cat.lastFlashcardReview = now;

          if (isCorrect) {
            cat.flashcardCorrect = (cat.flashcardCorrect || 0) + 1;
          }
        }
      }

      state.appState.version = (state.appState.version || 0) + 1;
      state.appState.lastUpdated = new Date().toISOString();
      markStorageDirty();
    });

    if (typeof get().awardExperience === 'function') {
      const xp = rating >= 2 ? 3 : 1;
      get().awardExperience(xp);
    }
  },
});

