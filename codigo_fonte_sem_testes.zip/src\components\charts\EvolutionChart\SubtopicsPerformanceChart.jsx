import React, { useMemo, useState, useId, useCallback } from 'react';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
    ResponsiveContainer, LabelList, Cell, ReferenceLine,
    LineChart, Line, Legend
} from "recharts";
import { normalizeDate, getDateKey, formatDisplayDate, parseNoonLocal } from "../../../utils/dateHelper";
import { getSafeScore, formatValue, getSyntheticTotal } from "../../../utils/scoreHelper";
import { simpleHash, toArray } from "../../../utils/evolutionGuards";
import { ChartFrame } from "../ChartFrame";

const CustomTooltipStyle = {
    backgroundColor: 'rgba(15, 23, 42, 0.9)',
    backdropFilter: 'blur(16px)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '12px',
    padding: '12px 16px',
    fontSize: '12px',
    boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
};

const MEGA_PALETTE = [
    "#ef4444", "#f97316", "#f59e0b", "#84cc16", "#22c55e",
    "#10b981", "#14b8a6", "#06b6d4", "#0ea5e9", "#3b82f6",
    "#6366f1", "#8b5cf6", "#a855f7", "#d946ef", "#ec4899",
    "#f43f5e", "#fb7185", "#34d399", "#fbbf24", "#a3e635"
];

const CustomLineTooltip = React.memo(({ active, payload, label, targetScorePct }) => {
    const safeFix = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v).toFixed(d) : "0");
    
    if (active && payload && payload.length) {
        const sortedPayload = [...payload].sort((a, b) => b.value - a.value);

        return (
            <div className="bg-slate-950/95 border border-white/10 p-4 rounded-2xl shadow-[0_15px_40px_rgba(0,0,0,0.7)] backdrop-blur-xl min-w-[320px] z-50">
                {(() => {
                  const parsedLabel = parseNoonLocal(label) || new Date(label);
                
                  const formattedLabel = Number.isFinite(parsedLabel?.getTime?.())
                    ? `${String(parsedLabel.getDate()).padStart(2, '0')}/${String(parsedLabel.getMonth() + 1).padStart(2, '0')}`
                    : String(label);
                
                  return (
                    <p className="text-[10px] font-black text-amber-400 uppercase tracking-widest mb-3 border-b border-white/10 pb-2 flex justify-between items-center">
                      <span>📅 {formattedLabel}</span>
                      <span>Meta: {targetScorePct.toFixed(1)}%</span>
                    </p>
                  );
                })()}
                <div className="space-y-4">
                    {sortedPayload.map((entry, index) => {
                        const pct = Math.max(0, Math.min(100, entry.value));
                        const topicKey = entry.dataKey;
                        const total = entry.payload[`${topicKey}_total`];
                        const correct = entry.payload[`${topicKey}_correct`];
                        const delta = entry.payload[`${topicKey}_delta`];
                        
                        const isTargetMet = pct >= targetScorePct;
                        const gap = isTargetMet ? 0 : Math.max(0, targetScorePct - pct);
                        
                        return (
                            <div key={`item-${index}`} className="flex flex-col gap-1.5">
                                <div className="flex justify-between items-end">
                                    <div className="flex flex-col gap-0.5">
                                        <span style={{ color: entry.color }} className="font-bold flex items-center gap-2 min-w-0 max-w-[200px]" title={entry.name}>
                                            <span className="w-2 h-2 rounded-sm shrink-0" style={{ backgroundColor: entry.color, boxShadow: `0 0 8px ${entry.color}88` }}></span>
                                            <span className="truncate">{entry.name}</span>
                                            {isTargetMet && <span title="Meta atingida" className="text-[10px] shrink-0 drop-shadow-md">🔥</span>}
                                        </span>
                                        <span className="text-[9px] text-slate-400 font-mono ml-4 flex items-center gap-1.5">
                                            <span className="bg-slate-900 px-1 rounded border border-white/5">Vol: {correct}/{total}</span>
                                            {gap > 0 && <span className="text-rose-400/70">Falta {safeFix(gap, 1)}%</span>}
                                        </span>
                                    </div>
                                    <div className="flex flex-col items-end gap-0.5 shrink-0">
                                        <span className="font-mono font-black text-white text-[13px] drop-shadow-md leading-none">
                                            {safeFix(entry.value, 1)}%
                                        </span>
                                        {delta !== undefined && delta !== null && (
                                            <span className={`text-[9px] font-black font-mono leading-none ${delta > 0 ? 'text-emerald-400' : delta < 0 ? 'text-rose-400' : 'text-slate-500'}`}>
                                                {delta > 0 ? '▲ +' : delta < 0 ? '▼ ' : '■ '}{safeFix(delta, 1)}%
                                            </span>
                                        )}
                                    </div>
                                </div>
                                <div className="w-full h-1.5 bg-slate-900/80 rounded-full overflow-hidden border border-white/5 shadow-inner mt-0.5">
                                    <div 
                                        className="h-full rounded-full transition-all duration-500 ease-out relative" 
                                        style={{ width: `${pct}%`, backgroundColor: entry.color, boxShadow: `0 0 10px ${entry.color}88` }}
                                    >
                                        <div className="absolute right-0 top-0 bottom-0 w-4 bg-gradient-to-l from-white/30 to-transparent"></div>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    }
    return null;
});

export const SubtopicsPerformanceChart = React.memo(({ 
    categories = [], 
    focusSubjectId, 
    showOnlyFocus, 
    timeWindow, 
    targetScore = 80, 
    minScore = 0,
    maxScore = 100 
}) => {
    const instanceId = useId().replace(/:/g, "");
    const [viewMode, setViewMode] = useState('bars');
    const accuracyUnit = '%';
    
    // FIX 5A: garantir range mínimo e fallback sensato
    const safeMinScorePct = Number.isFinite(Number(minScore)) ? Number(minScore) : 0;
    const safeMaxScorePct = Number(maxScore) > safeMinScorePct ? Number(maxScore) : safeMinScorePct + 1;
    const safeRangePct = Math.max(1e-9, safeMaxScorePct - safeMinScorePct);
    
    const safeTargetScorePctRaw = Number.isFinite(Number(targetScore))
      ? Number(targetScore)
      : safeMinScorePct;
    
    const safeTargetScorePctClamped = Math.max(
      safeMinScorePct,
      Math.min(safeMaxScorePct, safeTargetScorePctRaw)
    );
    
    const targetScorePct = Math.max(
      0,
      Math.min(
        100,
        ((safeTargetScorePctClamped - safeMinScorePct) / safeRangePct) * 100
      )
    );

    const renderLineTooltip = useCallback(
        (props) => <CustomLineTooltip {...props} targetScorePct={targetScorePct} />,
        [targetScorePct]
    );

    const limitMs = useMemo(() => {
        const now = new Date();
        now.setHours(23, 59, 59, 999);
        if (timeWindow !== "all") {
            const days = parseInt(timeWindow, 10);
            if (Number.isFinite(days) && days > 0) {
                const pastDate = new Date();
                pastDate.setDate(pastDate.getDate() - days);
                pastDate.setHours(0, 0, 0, 0);
                return pastDate.getTime();
            }
        }
        return 0;
    }, [timeWindow]);

    const relevantCategories = useMemo(() => {
        return categories.filter(cat => !showOnlyFocus || cat.id === focusSubjectId);
    }, [categories, showOnlyFocus, focusSubjectId]);

    const chartData = useMemo(() => {
        const topicMap = {};
        const safeMaxScore = Math.max(1, Number(maxScore) || 100);
        const safeMinScore = Number.isFinite(Number(minScore)) ? Number(minScore) : 0;

        relevantCategories.forEach(cat => {
            const history = Array.isArray(cat.simuladoStats?.history) ? cat.simuladoStats.history : Object.values(cat.simuladoStats?.history || {});
            if (!history.length) return;

            const catMax = Number(cat.maxScore) > 0 ? Number(cat.maxScore) : safeMaxScore;
            const catMin = Number.isFinite(Number(cat.minScore)) ? Number(cat.minScore) : safeMinScore;
            const catRange = Math.max(1e-9, catMax - catMin);

            const recentHistory = history.filter(h => {
                if (!limitMs) return true;
                const d = normalizeDate(h?.date || h?.createdAt);
                return d && d.getTime() >= limitMs;
            });

            for (let i = 0; i < recentHistory.length; i++) {
                const h = recentHistory[i];

                toArray(h.topics).forEach(t => {
                    const rawName = String(t.name || '').replace(/^\[(.*?)\]\s*/i, '').replace(/<[^>]*>?/gm, '').trim();
                    const n = rawName.charAt(0).toUpperCase() + rawName.slice(1).toLowerCase();
                    if (!n || n.toLowerCase() === 'nenhum') return;
                    const key = n.toLowerCase();

                    if (!topicMap[key]) {
                        topicMap[key] = { name: n, correct: 0, total: 0 };
                    }

                    let total = parseInt(t.total, 10) || 0;
                    if (t.isPercentage) {
                        if (total === 0) total = getSyntheticTotal(catMax);
                    } else if (total === 0 && t.score != null) {
                        total = getSyntheticTotal(catMax);
                    }
                    if (total === 0) return;
                    
                    const rawC = Number(t.correct);
                    let correctCount = (Number.isFinite(rawC) && !t.isPercentage) ? rawC : NaN;

                    if (!Number.isFinite(correctCount)) {
                        const rawScore = getSafeScore(t, catMax, catMin);
                        const score = Number.isFinite(rawScore) ? rawScore : catMin;
                        const normalizedScore = Math.max(catMin, Math.min(catMax, score));
                        correctCount = total > 0 ? ((normalizedScore - catMin) / catRange) * total : 0;
                    }
                    correctCount = Math.max(0, Math.min(total, Number.isFinite(correctCount) ? correctCount : 0));

                    topicMap[key].total += total;
                    topicMap[key].correct += correctCount;
                });
            }
        });

        return Object.values(topicMap)
            .filter(d => d.total > 0)
            .map(d => {
                const rawAcc = (d.correct / d.total) * 100;
                const acc = Number.isFinite(rawAcc) ? rawAcc : 0;
                return {
                    name: d.name.length > 25 ? d.name.substring(0, 23) + '...' : d.name,
                    fullName: d.name,
                    correct: Math.round(d.correct),
                    total: Math.round(d.total),
                    accuracy: Number(acc.toFixed(2)),
                };
            })
            .sort((a, b) => a.accuracy - b.accuracy);
    }, [relevantCategories, limitMs, maxScore, minScore]);


    const { timeSeriesData, uniqueTopics } = useMemo(() => {
        const dateMap = {}; 
        const topicVolumeMap = {}; 
        const safeMaxScore = Math.max(1, Number(maxScore) || 100);
        const safeMinScore = Number.isFinite(Number(minScore)) ? Number(minScore) : 0;

        const toTopicKey = (name) => {
          const normalized = String(name || '').trim().toLowerCase();
          const slug = normalized.replace(/[^a-z0-9]+/g, '_');
          return `top_${slug}_${simpleHash(normalized)}`;
        };

        relevantCategories.forEach(cat => {
            const history = Array.isArray(cat.simuladoStats?.history) ? cat.simuladoStats.history : Object.values(cat.simuladoStats?.history || {});
            if (!history.length) return;

            const catMax = Number(cat.maxScore) > 0 ? Number(cat.maxScore) : safeMaxScore;
            const catMin = Number.isFinite(Number(cat.minScore)) ? Number(cat.minScore) : safeMinScore;
            const catRange = Math.max(1e-9, catMax - catMin);

            const recentHistory = history.filter(h => {
                if (!limitMs) return true;
                const d = normalizeDate(h?.date || h?.createdAt);
                return d && d.getTime() >= limitMs;
            });

            for (const h of recentHistory) {
                const d = normalizeDate(h?.date || h?.createdAt);
                if (!d) continue;
                const dateKey = getDateKey(d);
                if (!dateKey) continue;
                const dateLabel = formatDisplayDate(dateKey);

                if (!dateMap[dateKey]) {
                    dateMap[dateKey] = { dateLabel, originalDate: d.getTime() };
                }

                toArray(h.topics).forEach(t => {
                    const rawName = String(t.name || '').replace(/^\[(.*?)\]\s*/i, '').replace(/<[^>]*>?/gm, '').trim();
                    const topicName = rawName.charAt(0).toUpperCase() + rawName.slice(1).toLowerCase();
                    if (!topicName || topicName.toLowerCase() === 'nenhum') return;
                    
                    let total = parseInt(t.total, 10) || 0;
                    if (t.isPercentage) {
                        if (total === 0) total = getSyntheticTotal(catMax);
                    } else if (total === 0 && t.score != null) {
                        total = getSyntheticTotal(catMax);
                    }
                    if (total === 0) return;

                    topicVolumeMap[topicName] = (topicVolumeMap[topicName] || 0) + total;

                    const rawC = Number(t.correct);
                    let correct = (Number.isFinite(rawC) && !t.isPercentage) ? rawC : NaN;

                    if (!Number.isFinite(correct)) {
                        const rawScore = getSafeScore(t, catMax, catMin);
                        const score = Number.isFinite(rawScore) ? rawScore : catMin;
                        const normalizedScore = Math.max(catMin, Math.min(catMax, score));
                        correct = total > 0 ? ((normalizedScore - catMin) / catRange) * total : 0;
                    }
                    correct = Math.max(0, Math.min(total, Number.isFinite(correct) ? correct : 0));

                    const sKey = toTopicKey(topicName);
                    const totKey = `${sKey}_total`;
                    const corKey = `${sKey}_correct`;

                    if (dateMap[dateKey][totKey] === undefined) {
                        dateMap[dateKey][totKey] = 0;
                        dateMap[dateKey][corKey] = 0;
                    }
                    dateMap[dateKey][totKey] += total;
                    dateMap[dateKey][corKey] += correct;
                });
            }
        });

        const topTopicNames = Object.entries(topicVolumeMap)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 8)
            .map(entry => entry[0]);

        const topTopics = topTopicNames
          .map(name => ({
            name,
            key: toTopicKey(name)
          }))
          .filter((topic, index, self) => self.findIndex(t => t.key === topic.key) === index);

        let series = Object.values(dateMap).sort((a, b) => a.originalDate - b.originalDate);

        let prevAccMap = {};
        series.forEach(entry => {
            topTopics.forEach(topic => {
                const tot = entry[`${topic.key}_total`];
                const cor = entry[`${topic.key}_correct`];
                if (tot !== undefined && tot > 0) {
                    const accRaw = (cor / tot) * 100;
                    const safeAccRaw = Number.isFinite(accRaw) ? accRaw : 0;
                    const acc = Number(Math.max(0, Math.min(100, safeAccRaw)).toFixed(2));
                    entry[topic.key] = acc;
                    
                    if (prevAccMap[topic.key] !== undefined) {
                        entry[`${topic.key}_delta`] = Number((acc - prevAccMap[topic.key]).toFixed(2));
                    } else {
                        entry[`${topic.key}_delta`] = null;
                    }
                    prevAccMap[topic.key] = acc;
                }
            });
        });

        series = series.filter(entry => {
            return topTopics.some(topic => entry[topic.key] !== undefined);
        });

        return { timeSeriesData: series, uniqueTopics: topTopics };
    }, [relevantCategories, limitMs, maxScore, minScore]);


    return (
        <div className="rounded-3xl border border-slate-800/80 bg-slate-900/60 backdrop-blur-md p-4 sm:p-6 shadow-xl w-full min-h-[600px]" id={`subtopics_container_${instanceId}`}>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-5 px-1 gap-3">
                <div>
                    <h3 className="text-lg font-black bg-clip-text text-transparent bg-gradient-to-r from-yellow-300 via-amber-400 to-amber-500 mb-0.5 tracking-tight">
                        Raio-X de Tópicos
                    </h3>
                    <p className="text-slate-400 text-xs mt-0.5">Taxa de acertos real por assunto e volume de questões realizadas.</p>
                </div>

                <div className="flex items-center gap-1.5 bg-slate-950/80 border border-slate-800 p-1 rounded-2xl shadow-inner shrink-0 w-full sm:w-auto">
                    <button
                        onClick={() => setViewMode('bars')}
                        className={`flex-1 sm:flex-none px-4 py-1.5 text-[11px] font-black uppercase tracking-wider rounded-xl transition-all will-change-transform ${viewMode === 'bars' ? 'bg-amber-500/25 text-amber-300 border border-amber-500/40 shadow-sm' : 'text-slate-400 hover:text-slate-200 border border-transparent hover:bg-slate-800/40'}`}
                        aria-pressed={viewMode === 'bars'}
                    >
                        Ranking (Barras)
                    </button>
                    <button
                        onClick={() => setViewMode('lines')}
                        className={`flex-1 sm:flex-none px-4 py-1.5 text-[11px] font-black uppercase tracking-wider rounded-xl transition-all will-change-transform ${viewMode === 'lines' ? 'bg-indigo-500/25 text-indigo-300 border border-indigo-500/40 shadow-sm' : 'text-slate-400 hover:text-slate-200 border border-transparent hover:bg-slate-800/40'}`}
                        aria-pressed={viewMode === 'lines'}
                    >
                        Tempo (Linhas)
                    </button>
                </div>
            </div>

            {chartData.length === 0 ? (
                <div className="h-[280px] flex flex-col items-center justify-center gap-4 rounded-2xl border border-slate-800 bg-slate-950/30 mt-4">
                    <span className="text-5xl opacity-40">⏳</span>
                    <div className="text-center">
                        <p className="text-slate-300 font-bold text-base mb-1">Nenhum assunto no período atual</p>
                        <p className="text-slate-500 text-xs mt-1">Altere o filtro de período para <b className="text-slate-400">Tudo</b> caso seus simulados sejam mais antigos.</p>
                    </div>
                </div>
            ) : viewMode === 'bars' ? (
                <div className="w-full overflow-x-auto custom-scrollbar pb-2">
                    <div className="min-w-[520px] lg:min-w-full relative" style={{ height: Math.max(450, chartData.length * 60) }}>
                        <ChartFrame minHeight={450} label="Analisando subtópicos">
                            <ResponsiveContainer width="100%" height="100%" minHeight={450} minWidth={1}>
                            <BarChart data={chartData} layout="vertical" margin={{ top: 10, right: 120, left: 0, bottom: 0 }}>
                                <defs>
                                    <linearGradient id={`gradGood_${instanceId}`} x1="0" y1="0" x2="1" y2="0">
                                        <stop offset="0%" stopColor="#10b981" stopOpacity={0.7}/>
                                        <stop offset="100%" stopColor="#34d399" stopOpacity={1}/>
                                    </linearGradient>
                                    <linearGradient id={`gradWarn_${instanceId}`} x1="0" y1="0" x2="1" y2="0">
                                        <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.7}/>
                                        <stop offset="100%" stopColor="#fbbf24" stopOpacity={1}/>
                                    </linearGradient>
                                    <linearGradient id={`gradBad_${instanceId}`} x1="0" y1="0" x2="1" y2="0">
                                        <stop offset="0%" stopColor="#ef4444" stopOpacity={0.7}/>
                                        <stop offset="100%" stopColor="#f87171" stopOpacity={1}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" horizontal={false} />

                                <XAxis
                                    type="number"
                                    domain={[0, 100]}
                                    stroke="#94a3b8"
                                    tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 600 }}
                                    axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                                    tickLine={false}
                                    tickFormatter={(v) => `${v}${accuracyUnit}`}
                                    allowDataOverflow={true}
                                />

                                    <YAxis
                                        type="category"
                                        dataKey="name"
                                        stroke="#cbd5e1"
                                        tick={(props) => {
                                            const { x, y, payload } = props;
                                            const text = payload?.value || "";
                                            const fullText = payload?.payload?.fullName || text;
                                            const maxLen = 24;
                                            const truncated = text.length > maxLen ? text.substring(0, maxLen - 3) + '...' : text;
                                            return (
                                                <g transform={`translate(${x},${y})`}>
                                                    <text x={-6} y={0} dy={4} textAnchor="end" fill="#cbd5e1" fontSize={11} fontWeight={600}>
                                                        <title>{fullText}</title>
                                                        {truncated}
                                                    </text>
                                                </g>
                                            );
                                        }}
                                        axisLine={false}
                                        tickLine={false}
                                        width={160}
                                    />

                                <Tooltip
                                    offset={30}
                                    cursor={{ fill: 'rgba(255,255,255,0.04)' }}
                                    contentStyle={CustomTooltipStyle}
                                    itemStyle={{ color: '#e2e8f0', fontWeight: 'bold' }}
                                    formatter={(value, name, props) => {
                                        const entry = props?.payload;
                                        if (!entry) return [value, name];
                                        return [`${formatValue(value)}% (${entry.correct || 0}/${entry.total || 0} acertos)`, 'Precisão'];
                                    }}
                                    labelFormatter={(label) => <span className="font-black text-amber-400 tracking-wider uppercase text-[10px]">{label}</span>}
                                />

                                <ReferenceLine 
                                    x={targetScorePct} 
                                    stroke="#10b981" 
                                    strokeDasharray="5 3" 
                                    strokeWidth={2}
                                    strokeOpacity={0.8}
                                    label={{ position: 'top', value: 'META', fill: '#34d399', fontSize: 10, fontWeight: 'bold' }}
                                />

                                <Bar dataKey="accuracy" radius={[0, 8, 8, 0]} barSize={26} fill="#6366f1" background={{ fill: 'rgba(255,255,255,0.03)', radius: [0, 8, 8, 0] }} isAnimationActive={true} animationDuration={800}>
                                    {chartData.map((entry, index) => {
                                        let barColor = `url(#gradBad_${instanceId})`;
                                        if (entry.accuracy >= targetScorePct) barColor = `url(#gradGood_${instanceId})`;
                                        else if (entry.accuracy >= 60) barColor = `url(#gradWarn_${instanceId})`;
                                        return <Cell key={`cell-${index}`} fill={barColor} />;
                                    })}
                                    <LabelList
                                        dataKey="accuracy"
                                        position="right"
                                        content={(props) => {
                                            const { x, y, width, height, value, index } = props;
                                            const entry = chartData[index];
                                            if (!entry) return null;
                                            return (
                                                <text x={x + width + 8} y={y + height / 2 + 4}>
                                                    <tspan fill="#ffffff" fontSize={11} fontWeight="900">{formatValue(value)}%</tspan>
                                                    <tspan fill="#94a3b8" fontSize={9.5} fontWeight="700" dx={6}>({entry.correct}/{entry.total})</tspan>
                                                </text>
                                            );
                                        }}
                                    />
                                </Bar>
                            </BarChart>
                            </ResponsiveContainer>
                        </ChartFrame>
                    </div>
                </div>
            ) : (
                // 🎯 FIX: Altura reduzida de 750px para 500px para caber melhor na tela
                <div className="w-full relative min-h-[500px]">
                    <div className="absolute top-0 right-4 text-[10px] text-indigo-400/60 font-mono z-10">
                        {uniqueTopics.length} tópicos plotados simultaneamente.
                    </div>
                    {timeSeriesData.length > 0 ? (
                        <div className="w-full overflow-x-auto custom-scrollbar pb-2">
                            <div className="min-w-[700px] lg:min-w-full">
                                <ChartFrame minHeight={500} label="Analisando subtópicos">
                                    <ResponsiveContainer width="100%" height={500} minWidth={1}>
                                    {/* 🎯 FIX: left de -20 para 0 para evitar corte do eixo Y */}
                                    <LineChart data={timeSeriesData} margin={{ top: 20, right: 30, left: 0, bottom: 50 }}>
                                        <CartesianGrid strokeDasharray="2 2" stroke="#1e2937" vertical={false} />

                                        <XAxis
                                            dataKey="originalDate"
                                            stroke="#64748b"
                                            tick={{ fontSize: 11, fill: '#94a3b8' }}
                                            axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                                            tickLine={false}
                                            tickFormatter={(val) => {
                                                const d = parseNoonLocal(val) || new Date(val);
                                                return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
                                            }}
                                        />

                                        <YAxis
                                            stroke="#64748b"
                                            domain={[0, 100]}
                                            tick={{ fontSize: 11, fill: '#94a3b8' }}
                                            axisLine={false}
                                            tickLine={false}
                                            tickFormatter={(v) => `${v}%`}
                                            allowDataOverflow={true}
                                        />

                                        <Tooltip
                                            offset={40}
                                            content={renderLineTooltip}
                                            cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 1, strokeDasharray: '4 4' }}
                                        />

                                        <ReferenceLine y={targetScorePct} stroke="rgba(52, 211, 153, 0.4)" strokeDasharray="4 4" label={{ position: 'top', value: 'META', fill: '#6ee7b7', fontSize: 10 }} />

                                        <Legend
                                            wrapperStyle={{ fontSize: '10px', paddingTop: '20px' }}
                                            iconType="circle"
                                        />

                                        {uniqueTopics.map((topic, index) => {
                                            const color = MEGA_PALETTE[index % MEGA_PALETTE.length];
                                            return (
                                                <Line connectNulls
                                                    key={topic.key || topic.name}
                                                    type="monotoneX"
                                                    dataKey={topic.key || topic.name}
                                                    name={topic.name}
                                                    stroke={color}
                                                    strokeWidth={3}
                                                    dot={{ r: 3, fill: '#0f172a', strokeWidth: 1.5, stroke: color }}
                                                    activeDot={{ r: 5, fill: color, stroke: '#ffffff', strokeWidth: 2 }}
                                                    animationDuration={1500}
                                                    animationEasing="ease-in-out"
                                                />
                                            );
                                        })}
                                    </LineChart>
                                    </ResponsiveContainer>
                                </ChartFrame>
                            </div>
                        </div>
                    ) : (
                        <div className="h-[250px] flex flex-col items-center justify-center text-slate-500 italic">
                            <span className="text-3xl mb-2">📉</span>
                            <p>Dados insuficientes no período.</p>
                            <p className="text-xs">Faça simulados em dias diferentes para formar a linha do tempo.</p>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
});

