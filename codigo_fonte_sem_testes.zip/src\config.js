// Global application configuration and constants

export const SYNC_LOG_CAP = 500;
export const MAX_BACKUP_SIZE = 5 * 1024 * 1024; // 5MB limit for JSON backups
export const DEBUG_MODE = import.meta.env?.DEV || false;

export default {
    SYNC_LOG_CAP,
    MAX_BACKUP_SIZE,
    DEBUG_MODE
};

