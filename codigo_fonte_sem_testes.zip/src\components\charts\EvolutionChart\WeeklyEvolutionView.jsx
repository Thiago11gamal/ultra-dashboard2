import React, { useMemo, useState, useCallback } from 'react';
import {
    LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
    Tooltip, ResponsiveContainer, ReferenceLine, Legend, Cell, Brush
} from 'recharts';
import { TrendingUp, BarChart3, HelpCircle, Zap } from 'lucide-react';
import { getSafeScore, formatValue, getSyntheticTotal } from "../../../utils/scoreHelper";
import WeeklyPerformanceChart from './WeeklyPerformanceChart';
import { computeTopRegressions, computeTrendKpi } from '../../../utils/weeklyEvolutionInsights.js';
import { parseNoonLocal, getDateKey } from '../../../utils/dateHelper';
import { toArray, getHistoryDate } from '../../../utils/evolutionGuards';
import { ratioToPoints } from '../../../utils/scoreHelper.conversions';

const WeeklyTooltip = React.memo(({ active, payload, label, hiddenKeys = {}, unit, stableThreshold = 2 }) => {
    if (!active || !payload || !payload.length) return null;

    const hasValidData = payload.some(entry =>
        Number.isFinite(Number(entry?.value))
    );
    if (!hasValidData) return null;

    const visibleEntries = payload.filter((entry) => {
        const dataKey = String(entry.dataKey || '');
        const isDelta = dataKey.startsWith('delta_');
        const baseKey = isDelta ? dataKey.replace('delta_', '') : dataKey;
        return !hiddenKeys[baseKey] && entry.value != null && Number.isFinite(Number(entry.value));
    });

    if (visibleEntries.length === 0) return null;

    return (
        <div className="bg-slate-950/80 border border-white/10 p-4 rounded-xl shadow-[0_8px_32px_rgba(0,0,0,0.5)] backdrop-blur-xl min-w-[220px] max-w-[320px] break-words whitespace-normal">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 border-b border-white/10 pb-2">
                Semana de {label}
            </p>
            <div className="space-y-3">
                {visibleEntries.map((entry, idx) => {
                    const dataKey = String(entry.dataKey || '');
                    const isDelta = dataKey.startsWith('delta_');
                    const baseKey = isDelta ? dataKey.replace('delta_', '') : dataKey;

                        if (hiddenKeys[baseKey]) return null;

                        const val = entry.value;
                        if (val == null) return null;

                        const meta = entry.payload[`meta_${baseKey}`];

                        if (isDelta) {
                            const isStable = Math.abs(val) <= stableThreshold;
                            const color = entry.payload[`deltaColor_${baseKey}`] || (isStable ? '#eab308' : val > 0 ? '#10b981' : val < 0 ? '#ef4444' : '#94a3b8');
                            const prefix = val > 0 ? '+' : '';
                            const currentPct = (meta?.currPct === null || meta?.currPct === undefined || meta?.currPct === '') ? entry.payload?.[baseKey] : (Number.isFinite(Number(meta?.currPct)) ? meta.currPct : entry.payload?.[baseKey]);

                            return (
                                <div key={idx} className="flex flex-col gap-0.5">
                                    <div className="flex justify-between items-center text-[10px]">
                                        <span style={{ color: entry.color || '#fff' }} className="font-bold flex items-center gap-1.5">
                                            <span className="w-1.5 h-1.5 rounded-sm" style={{ backgroundColor: entry.color }}></span>
                                            {entry.name.replace(' (Var.)', '')}
                                        </span>
                                        <span style={{ color }} className="font-mono font-black text-xs">
                                            {prefix}{formatValue(val)}{unit}
                                        </span>
                                    </div>
                                    {meta && meta.prevPct != null && Number.isFinite(Number(currentPct)) && (
                                        <div className="flex justify-between text-[8px] text-slate-500 pl-3">
                                            <span>De {formatValue(meta.prevPct)}{unit}</span>
                                            <span>
                                                Para {formatValue(currentPct)}{unit} <strong style={{ color }}>(Δ {prefix}{formatValue(val)}{unit})</strong>
                                            </span>
                                        </div>
                                    )}
                                </div>
                            );
                        } else {
                            return (
                                <div key={idx} className="flex flex-col gap-0.5">
                                    <div className="flex justify-between items-center text-[10px]">
                                        <span style={{ color: entry.color || '#fff' }} className="font-bold flex items-center gap-1.5">
                                            <span className="w-2 h-2 rounded-sm" style={{ backgroundColor: entry.color }}></span>
                                            {entry.name}
                                        </span>
                                        <span className="font-mono font-bold text-white text-xs">
                                            {formatValue(val)}{unit}
                                        </span>
                                    </div>
                                    {meta && meta.currTot > 0 && (
                                        <span className="text-[8px] text-slate-500 pl-3.5 italic">
                                            Volume: {meta.currTot} questões
                                        </span>
                                    )}
                                </div>
                            );
                        }
                    })}
                </div>
            </div>
        );
});

const getMondayStr = (dateStr) => {
    const dt = parseNoonLocal(dateStr);
    // ✅ BUG-3 FIX: parseNoonLocal pode retornar null → guard antes de getTime()
    if (!dt || isNaN(dt.getTime())) return null;
    const dayOfWeek = dt.getDay();
    const diff = dt.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
    dt.setDate(diff);
    const y = dt.getFullYear();
    const m = String(dt.getMonth() + 1).padStart(2, '0');
    const d = String(dt.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
};

const formatWeek = (isoString) => {
    if (!isoString || typeof isoString !== 'string') return '--/--';
    const [year, month, day] = isoString.split('-');
    if (!year || !month || !day) return '--/--';
    return `${day}/${month}`;
};

const shortenLabel = (value, max = 18) => {
    const text = String(value || '').trim();
    if (!text) return '—';
    return text.length > max ? `${text.slice(0, max - 1)}…` : text;
};

export const WeeklyEvolutionView = ({
    categories,
    studyLogs = [],
    showOnlyFocus,
    focusSubjectId,
    maxScore = 100,
    minScore = 0,
    unit = '%'
}) => {
    const [viewMode, setViewMode] = useState('performance');

    // A1 FIX: Padrão idiomático do React para resetar estado derivado de props sem useEffect.
    // Em vez de setUserToggles({}) dentro de useEffect (que causa render duplo e dispara a
    // regra react-hooks/set-state-in-effect), rastreamos a "chave de foco" anterior e chamamos
    // setState DURANTE o render quando ela muda. O React descarta o render parcial e reinicia
    // com o novo estado — isso é um render único, sem o ciclo extra do useEffect.
    // Ref: https://react.dev/learn/you-might-not-need-an-effect#adjusting-some-state-when-a-prop-changes
    const focusKey = `${showOnlyFocus}-${focusSubjectId}`;
    const [lastFocusKey, setLastFocusKey] = useState(focusKey);
    const [userToggles, setUserToggles] = useState({});

    if (lastFocusKey !== focusKey) {
        setLastFocusKey(focusKey);
        setUserToggles({});
    }

    const [hoveredLine, setHoveredLine] = useState(null);

    const { chartData, activeKeys, rankedKeys } = useMemo(() => {
        let itemsMap = {};
        const toSafeKey = (name) => {
            const clean = String(name || '')
                .trim()
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .toLowerCase()
                .replace(/[^a-z0-9_]/g, '_');
            return `top_${clean}`;
        };

        if (!showOnlyFocus || !focusSubjectId) {
            categories.forEach(cat => {
                if (!cat?.id) return;
                const fullName = String(cat.name || 'Matéria').replace(/Direito /gi, 'D. ');
                const safeName = shortenLabel(fullName, 18);
                const safeColor = typeof cat.color === 'string' ? cat.color : '#3b82f6';
                itemsMap[cat.id] = { name: safeName, fullName: fullName, color: safeColor };
            });
        } else {
            const cat = categories.find(c => c.id === focusSubjectId);
            if (cat) {
                (cat.tasks || []).forEach(task => {
                    const tName = String(task?.text || '').replace(/^\[(.*?)\]\s*/i, '').trim();
                    if (!tName) return;
                    const key = toSafeKey(tName);
                    itemsMap[key] = { name: shortenLabel(tName, 18), color: cat.color || '#3b82f6', fullName: tName };
                });

                const hArray = Array.isArray(cat.simuladoStats?.history) ? cat.simuladoStats.history : Object.values(cat.simuladoStats?.history || {});
                hArray.forEach(h => {
                    const topics = toArray(h.topics);
                    
                    if (topics.length > 0) {
                        topics.forEach(t => {
                            const tName = String(t.name || '').replace(/^\[(.*?)\]\s*/i, '').trim();
                            if (!tName) return;
                            const key = toSafeKey(tName);
                            if (!itemsMap[key]) {
                                itemsMap[key] = { name: shortenLabel(tName, 18), color: cat.color || '#3b82f6', fullName: tName };
                            }
                        });
                    } else if (h.taskId) {
                        const rawTaskText = cat.tasks?.find(task => task.id === h.taskId)?.text || 'Assunto';
                        const tName = String(rawTaskText).replace(/^\[(.*?)\]\s*/i, '').trim() || 'Assunto';
                        const key = toSafeKey(tName);
                        if (!itemsMap[key]) {
                            itemsMap[key] = { name: shortenLabel(tName, 18), color: cat.color || '#3b82f6', fullName: tName };
                        }
                    } else if (h.topic || h.assunto || h.subtopic || h.topicName) {
                        const rawTopicText = h.topic || h.assunto || h.subtopic || h.topicName;
                        const tName = String(rawTopicText).replace(/^\[(.*?)\]\s*/i, '').trim() || 'Assunto';
                        const key = toSafeKey(tName);
                        if (!itemsMap[key]) {
                            itemsMap[key] = { name: shortenLabel(tName, 18), color: cat.color || '#3b82f6', fullName: tName };
                        }
                    } else {
                        if (!itemsMap['top_geral']) {
                            itemsMap['top_geral'] = { name: 'Geral', color: cat.color || '#3b82f6', fullName: 'Geral' };
                        }
                    }
                });
            }
        }

        const validIds = Object.keys(itemsMap);
        if (validIds.length === 0) return { chartData: [], activeKeys: {}, rankedKeys: [] };

        const safeMinScore = Number.isFinite(Number(minScore)) ? Number(minScore) : 0;
        const safeMaxScore = Number.isFinite(Number(maxScore)) ? Number(maxScore) : 100;
        const lowerBound = Math.min(safeMinScore, safeMaxScore);
        const upperBound = Math.max(safeMinScore, safeMaxScore);
        const scoreRange = Math.max(1e-9, upperBound - lowerBound);
        const stableThreshold = Math.max(0.5, scoreRange * 0.02);
        const fromRatio = (ratio) => ratioToPoints(ratio, upperBound, lowerBound);
        const weeksTemp = {};

        const processHistory = (historyArray, itemId, cMax = upperBound, cMin = lowerBound) => {
            if (!Array.isArray(historyArray) || !itemId) return;
            const cRange = Math.max(1e-9, cMax - cMin);
            historyArray.forEach(h => {
                const weekStr = getMondayStr(getHistoryDate(h));
                if (!weekStr) return;

                if (!weeksTemp[weekStr]) weeksTemp[weekStr] = { week: weekStr };
                if (!weeksTemp[weekStr][itemId]) weeksTemp[weekStr][itemId] = { correct: 0, total: 0 };

                let totalQ = Math.max(0, Number(h.total ?? h.questoes ?? h.totalQuestoes ?? h.questions) || 0);
                let corr = 0;
                const hasValidC = (h.correct !== undefined && h.correct !== null && String(h.correct).trim() !== '') ||
                                  (h.acertos !== undefined && h.acertos !== null && String(h.acertos).trim() !== '') ||
                                  (h.correctCount !== undefined && h.correctCount !== null && String(h.correctCount).trim() !== '');
                if (hasValidC && !h.isPercentage) {
                    const rawC = Math.max(0, Number(h.correct ?? h.acertos ?? h.correctCount) || 0);
                    if (totalQ === 0) totalQ = rawC > 0 ? rawC : getSyntheticTotal(cMax);
                    corr = Math.min(totalQ, Number.isFinite(rawC) ? rawC : 0);
                } else {
                    const score = getSafeScore(h, cMax, cMin);
                    if (!Number.isFinite(score)) return;
                    if (totalQ === 0 && h.score != null) {
                        totalQ = getSyntheticTotal(cMax);
                    }
                    if (totalQ === 0) return;
                    corr = Math.max(0, Math.min(1, (score - cMin) / cRange)) * totalQ;
                }
                if (totalQ === 0) return;

                weeksTemp[weekStr][itemId].total += totalQ;
                weeksTemp[weekStr][itemId].correct += corr;
            });
        };

        if (!showOnlyFocus || !focusSubjectId) {
            categories.forEach(cat => {
                const hArray = Array.isArray(cat.simuladoStats?.history) ? cat.simuladoStats.history : Object.values(cat.simuladoStats?.history || {});
                const cMax = Number.isFinite(Number(cat?.maxScore)) && Number(cat?.maxScore) > 0 ? Number(cat.maxScore) : upperBound;
                const cMin = Number.isFinite(Number(cat?.minScore)) ? Math.min(Number(cat.minScore), cMax) : lowerBound;
                processHistory(hArray, cat.id, cMax, cMin);
            });
        } else {
            const cat = categories.find(c => c.id === focusSubjectId);
            if (cat) {
                const cMax = Number.isFinite(Number(cat?.maxScore)) && Number(cat?.maxScore) > 0 ? Number(cat.maxScore) : upperBound;
                const cMin = Number.isFinite(Number(cat?.minScore)) ? Math.min(Number(cat.minScore), cMax) : lowerBound;
                const cRange = Math.max(1e-9, cMax - cMin);
                const hArray2 = Array.isArray(cat.simuladoStats?.history) ? cat.simuladoStats.history : Object.values(cat.simuladoStats?.history || {});
                hArray2.forEach(h => {
                    const topics = toArray(h.topics);
                    
                    if (topics.length > 0) {
                        topics.forEach(t => {
                            const tName = String(t.name || '').replace(/^\[(.*?)\]\s*/i, '').trim();
                            if (!tName) return;
                            const tId = toSafeKey(tName);
                            const weekStr = getMondayStr(getHistoryDate(h));
                            if (!weekStr) return;
                            if (!weeksTemp[weekStr]) weeksTemp[weekStr] = { week: weekStr };
                            if (!weeksTemp[weekStr][tId]) weeksTemp[weekStr][tId] = { correct: 0, total: 0 };

                            let totalQ = Math.max(0, Number(t.total ?? t.questoes ?? t.totalQuestoes ?? t.questions) || 0);
                            let corr = 0;
                            const hasValidC = (t.correct !== undefined && t.correct !== null && String(t.correct).trim() !== '') ||
                                              (t.acertos !== undefined && t.acertos !== null && String(t.acertos).trim() !== '') ||
                                              (t.correctCount !== undefined && t.correctCount !== null && String(t.correctCount).trim() !== '');
                            if (hasValidC && !t.isPercentage) {
                                const rawC = Math.max(0, Number(t.correct ?? t.acertos ?? t.correctCount) || 0);
                                if (totalQ === 0) totalQ = rawC > 0 ? rawC : getSyntheticTotal(cMax);
                                corr = Math.min(totalQ, Number.isFinite(rawC) ? rawC : 0);
                            } else {
                                const topicScore = getSafeScore(t, cMax, cMin);
                                if (!Number.isFinite(topicScore)) return;
                                if (totalQ === 0 && t.score != null) {
                                    totalQ = getSyntheticTotal(cMax);
                                }
                                if (totalQ === 0) return;
                                corr = Math.max(0, Math.min(1, (topicScore - cMin) / cRange)) * totalQ;
                            }
                            if (totalQ === 0) return;
                            weeksTemp[weekStr][tId].total += totalQ;
                            weeksTemp[weekStr][tId].correct += corr;
                        });
                    } else if (h.taskId) {
                        const rawTaskText = cat.tasks?.find(task => task.id === h.taskId)?.text || 'Assunto';
                        const tName = String(rawTaskText).replace(/^\[(.*?)\]\s*/i, '').trim() || 'Assunto';
                        const tId = toSafeKey(tName);
                        processHistory([h], tId, cMax, cMin);
                    } else if (h.topic || h.assunto || h.subtopic || h.topicName) {
                        const rawTopicText = h.topic || h.assunto || h.subtopic || h.topicName;
                        const tName = String(rawTopicText).replace(/^\[(.*?)\]\s*/i, '').trim() || 'Assunto';
                        const tId = toSafeKey(tName);
                        processHistory([h], tId, cMax, cMin);
                    } else {
                        processHistory([h], 'top_geral', cMax, cMin);
                    }
                });
            }
        }

        const sortedWeeks = Object.values(weeksTemp).sort((a, b) => a.week.localeCompare(b.week));
        if (sortedWeeks.length === 0) return { chartData: [], activeKeys: {}, rankedKeys: [] };

        const memoryByItem = {}; 

        const finalData = sortedWeeks.map(weekObj => {
            const dataPoint = {
                week: weekObj.week,
                displayDate: formatWeek(weekObj.week)
            };

            const currentWeekDate = parseNoonLocal(weekObj.week);
            const expectedPrevDate = currentWeekDate ? new Date(currentWeekDate) : null;
            if (expectedPrevDate) expectedPrevDate.setDate(expectedPrevDate.getDate() - 7);
            const expectedPrevKey = expectedPrevDate ? getDateKey(expectedPrevDate) : null;
            
            validIds.forEach(id => {
                const currentData = weekObj[id];

                if (currentData && currentData.total > 0) {
                    const ratio = currentData.correct / currentData.total;
                    const currentScore = fromRatio(ratio);
                    const safeCurrentScore = Number.isFinite(currentScore) ? currentScore : 0;
                    const currentPct = Number(
                        Math.max(lowerBound, Math.min(upperBound, safeCurrentScore)).toFixed(2)
                    );

                    dataPoint[id] = currentPct;

                    const last = memoryByItem[id];

                    if (last && last.week === expectedPrevKey) {
                        const prevPct = last.pct;
                        const safeDelta = Number.isFinite(currentPct - prevPct)
                            ? currentPct - prevPct
                            : 0;

                        const delta = Number(safeDelta.toFixed(2));
                        const isStable = Math.abs(delta) <= stableThreshold;

                        dataPoint[`delta_${id}`] = delta;
                        dataPoint[`deltaColor_${id}`] = isStable
                            ? '#eab308'
                            : delta > 0
                            ? '#10b981'
                            : '#ef4444';

                        dataPoint[`meta_${id}`] = {
                            currTot: currentData.total,
                            currPct: currentPct,
                            prevPct,
                            prevTot: last.total
                        };
                    } else {
                        dataPoint[`delta_${id}`] = null;
                        dataPoint[`deltaColor_${id}`] = '#94a3b8';

                        dataPoint[`meta_${id}`] = {
                            currTot: currentData.total,
                            currPct: currentPct,
                            prevPct: null,
                            prevTot: 0
                        };
                    }

                    memoryByItem[id] = {
                        pct: currentPct,
                        total: currentData.total,
                        week: weekObj.week
                    };
                } else {
                    dataPoint[id] = null;
                    dataPoint[`delta_${id}`] = null;
                    dataPoint[`deltaColor_${id}`] = '#94a3b8';
                }
            });

            return dataPoint;
        });

        const volumeTracker = {};
        validIds.forEach(id => volumeTracker[id] = 0);
        finalData.forEach(week => {
            validIds.forEach(id => {
                const meta = week[`meta_${id}`];
                if (meta && Number.isFinite(Number(meta.currTot))) volumeTracker[id] += Number(meta.currTot);
            });
        });
        const rankedKeys = [...validIds].sort((a, b) => volumeTracker[b] - volumeTracker[a]);

        return { chartData: finalData, activeKeys: itemsMap, rankedKeys };
    }, [categories, showOnlyFocus, focusSubjectId, maxScore, minScore]);

    const keys = Object.keys(activeKeys);

    const hiddenKeys = useMemo(() => {
        const result = {};
        rankedKeys?.forEach((key, idx) => {
            const defaultHide = showOnlyFocus ? false : idx >= 6; 
            if (userToggles[key] !== undefined) {
                result[key] = userToggles[key]; 
            } else {
                result[key] = defaultHide;
            }
        });
        return result;
    }, [rankedKeys, userToggles, showOnlyFocus]);

    const topRegressions = useMemo(() => computeTopRegressions({ viewMode, chartData, keys, activeKeys, hiddenKeys }), [viewMode, chartData, keys, activeKeys, hiddenKeys]);
    const trendKpi = useMemo(() => computeTrendKpi({ chartData, keys, hiddenKeys }), [chartData, keys, hiddenKeys]);

    const handleLegendClick = useCallback((e) => {
        const dataKey = e?.dataKey;
        if (!dataKey) return;
        const keyID = String(dataKey).replace('delta_', '');
        setUserToggles(prev => ({
            ...prev,
            [keyID]: !hiddenKeys[keyID] 
        }));
    }, [hiddenKeys]);

    const handleLegendHover = useCallback((e) => {
        if (e && e.dataKey) setHoveredLine(String(e.dataKey).replace('delta_', ''));
    }, []);

    const handleLegendLeave = useCallback(() => {
        setHoveredLine(null);
    }, []);

    const renderLegendText = useCallback((value, entry) => {
        const keyID = String(entry.dataKey || '').replace('delta_', '');
        const isHidden = hiddenKeys[keyID];
        const fullName = activeKeys[keyID]?.fullName || String(value || '');
        return (
            <span 
                className={`text-[10px] font-black uppercase tracking-widest transition-opacity cursor-pointer ${isHidden ? 'opacity-20' : 'opacity-100'}`}
                title={fullName}
            >
                {String(value || '').replace(' (Var.)', '')}
            </span>
        );
    }, [hiddenKeys, activeKeys]);

    const stableThreshold = useMemo(() => {
        const safeMinScore = Number.isFinite(Number(minScore)) ? Number(minScore) : 0;
        const safeMaxScore = Number.isFinite(Number(maxScore)) ? Number(maxScore) : 100;
        const scoreRange = Math.max(1e-9, Math.abs(safeMaxScore - safeMinScore));
        return Math.max(0.5, scoreRange * 0.02);
    }, [minScore, maxScore]);

    // M2 FIX: Tooltip extraído em useCallback para restaurar memoização do Recharts.
    // Arrow functions inline quebram a memoização porque criam nova referência a cada render.
    const renderWeeklyTooltip = useCallback(
        (props) => <WeeklyTooltip {...props} hiddenKeys={hiddenKeys} unit={unit} stableThreshold={stableThreshold} />,
        [hiddenKeys, unit, stableThreshold]
    );


    if (chartData.length < 1) {
        return (
            <div className="min-h-[400px] flex flex-col items-center justify-center bg-slate-950/40 rounded-3xl border border-slate-700/50 p-6 shadow-inner">
                <HelpCircle size={40} className="text-slate-600 mb-3" />
                <p className="text-sm font-semibold text-slate-300">Dados insuficientes</p>
                <p className="text-slate-500 text-[10px] mt-2 text-center max-w-[250px]">
                    Cadastre pelo menos uma semana de simulados para visualizar a curva de evolução e a variação semanal.
                </p>
            </div>
        );
    }

    return (
        <div className="w-full pt-4 animate-fade-in relative flex flex-col">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 px-2 gap-4 shrink-0">
                <div>
                    <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block mb-0.5">
                        Raio-X Temporal Avançado
                    </span>
                    <h3 className="text-lg font-black text-white uppercase tracking-tight">
                        {showOnlyFocus && focusSubjectId ? 'Semanas por Assunto' : 'Semanas por Matéria'}
                    </h3>
                    {trendKpi && (
                        <div className="inline-flex items-center gap-2 mt-1.5 px-2.5 py-1 rounded-lg bg-slate-900/80 border border-white/10 text-[10px] text-slate-400 font-mono">
                            <span>Tendência:</span>
                            <span className={`font-black ${trendKpi.delta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                {trendKpi.delta >= 0 ? '+' : ''}{formatValue(trendKpi.delta)}{unit}
                            </span> 
                            <span className="text-slate-500">({trendKpi.previousN} sem. → {trendKpi.recentN} sem.)</span>
                        </div>
                    )}
                </div>

                <div className="flex items-center bg-slate-900/90 border border-white/10 rounded-2xl p-1 shadow-inner backdrop-blur-md">
                    <button
                        onClick={() => setViewMode('performance')}
                        aria-label="Alternar para visão de desempenho semanal"
                        aria-pressed={viewMode === 'performance'}
                        className={`flex items-center justify-center gap-1.5 px-2.5 sm:px-3.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all will-change-transform ${
                            viewMode === 'performance' 
                                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-500/25 border border-indigo-400/30 font-bold' 
                                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                        }`}
                    >
                        <Zap size={13} className="shrink-0" /> <span className="sm:hidden">7 dias</span><span className="hidden sm:inline">Desempenho (7d)</span>
                    </button>
                    <button
                        onClick={() => setViewMode('evolution')}
                        aria-label="Alternar para visão de evolução semanal"
                        aria-pressed={viewMode === 'evolution'}
                        className={`flex items-center justify-center gap-1.5 px-2.5 sm:px-3.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all will-change-transform ${
                            viewMode === 'evolution' 
                                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-500/25 border border-indigo-400/30 font-bold' 
                                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                        }`}
                    >
                        <TrendingUp size={13} className="shrink-0" /> <span className="sm:hidden">Evol.</span><span className="hidden sm:inline">Evolução</span>
                    </button>
                    <button
                        onClick={() => setViewMode('variation')}
                        aria-label="Alternar para visão de variação semanal"
                        aria-pressed={viewMode === 'variation'}
                        className={`flex items-center justify-center gap-1.5 px-2.5 sm:px-3.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all will-change-transform ${
                            viewMode === 'variation' 
                                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-500/25 border border-indigo-400/30 font-bold' 
                                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                        }`}
                    >
                        <BarChart3 size={13} className="shrink-0" /> <span className="sm:hidden">Delta</span><span className="hidden sm:inline">Delta</span>
                    </button>
                </div>
            </div>

            <div className="h-[380px] w-full mt-2 relative">
                {viewMode === 'performance' ? (
                    <WeeklyPerformanceChart
                        categories={categories}
                        studyLogs={studyLogs}
                        showOnlyFocus={showOnlyFocus}
                        focusSubjectId={focusSubjectId}
                        maxScore={maxScore}
                        minScore={minScore}
                        unit={unit}
                    />
                ) : viewMode === 'variation' && chartData.length < 2 ? (
                    <div className="h-full flex flex-col items-center justify-center bg-slate-950/40 rounded-3xl border border-slate-800/60 p-6 text-center">
                        <BarChart3 size={36} className="text-slate-600 mb-2" />
                        <p className="text-sm font-bold text-slate-300">Semanas consecutivas necessárias</p>
                        <p className="text-xs text-slate-500 mt-1 max-w-xs">Registre simulados em pelo menos 2 semanas seguidas para calcular o acelerômetro de variação (Delta).</p>
                    </div>
                ) : (
                    <ResponsiveContainer width="100%" height="100%" minHeight={320} minWidth={1}>
                        {viewMode === 'evolution' ? (
                            <LineChart data={chartData} margin={{ top: 10, right: 10, left: 8, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />

                                <XAxis dataKey="displayDate" stroke="#64748b" fontSize={10} fontWeight={600} tickLine={false} axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} dy={10} minTickGap={15} />
                                <YAxis domain={[minScore, maxScore]} stroke="#64748b" fontSize={10} fontWeight={600} tickLine={false} axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} allowDataOverflow={false} tickFormatter={(v) => `${formatValue(v)}${unit}`} />
                                <Tooltip offset={20} content={renderWeeklyTooltip} cursor={{ stroke: 'rgba(255,255,255,0.15)', strokeWidth: 1.5, strokeDasharray: '4 4' }} />
                                <Legend verticalAlign="bottom" height={40} iconType="circle" formatter={renderLegendText} onClick={handleLegendClick} onMouseEnter={handleLegendHover} onMouseLeave={handleLegendLeave} wrapperStyle={{ paddingTop: '20px' }} />

                                {keys.map(key => {
                                    const isHovered = hoveredLine === key;
                                    const isOtherHovered = hoveredLine && hoveredLine !== key;
                                    
                                    return (
                                        <Line connectNulls
                                            key={key}
                                            type="monotoneX"
                                            dataKey={key}
                                            name={activeKeys[key].name}
                                            stroke={activeKeys[key].color}
                                            strokeWidth={isHovered ? 3.5 : (isOtherHovered ? 1.5 : 2)}
                                            strokeOpacity={isOtherHovered ? 0.4 : 1}
                                            dot={{ r: 3, strokeWidth: 1.5, stroke: activeKeys[key].color, fill: '#0f172a', strokeOpacity: isOtherHovered ? 0.4 : 1, fillOpacity: isOtherHovered ? 0.4 : 1 }}
                                            activeDot={{ r: 5, strokeWidth: 2, stroke: '#ffffff', fill: activeKeys[key].color, className: 'shadow-lg', opacity: isOtherHovered ? 0.4 : 1 }}
                                            hide={hiddenKeys[key]}
                                            isAnimationActive={true}
                                            animationDuration={800}
                                            animationEasing="ease-out"
                                            style={{ transition: 'all 0.3s ease' }}
                                        />
                                    );
                                })}

                                {chartData.length > 8 && (
                                    <Brush
                                        dataKey="week"
                                        height={22}
                                        stroke="#6366f1"
                                        fill="#0f172a"
                                        tickFormatter={formatWeek}
                                        className="text-[9px] font-mono"
                                        travellerWidth={10}
                                    />
                                )}
                            </LineChart>
                        ) : (
                            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 8, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />

                                <XAxis dataKey="displayDate" stroke="#64748b" fontSize={10} fontWeight={600} tickLine={false} axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} dy={10} minTickGap={15} />
                                <YAxis 
                                    stroke="#64748b" 
                                    fontSize={10} 
                                    fontWeight={600}
                                    tickLine={false} 
                                    axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} 
                                    tickFormatter={(v) => {
                                        const formatted = formatValue(v);
                                        if (formatted === "0.00" || formatted === "0") return `${formatted}${unit}`;
                                        return `${v > 0 ? '+' : ''}${formatted}${unit}`;
                                    }} 
                                />
                                <Tooltip offset={20} content={renderWeeklyTooltip} cursor={{ fill: 'rgba(255,255,255,0.04)' }} />
                                <Legend 
                                    verticalAlign="bottom" 
                                    height={60} 
                                    iconType="square" 
                                    formatter={renderLegendText} 
                                    onClick={handleLegendClick} 
                                    onMouseEnter={handleLegendHover} 
                                    onMouseLeave={handleLegendLeave} 
                                    wrapperStyle={{ paddingTop: '20px' }} 
                                />
                                <ReferenceLine y={0} stroke="rgba(255,255,255,0.15)" strokeDasharray="3 3" />

                                {chartData.length > 8 && (
                                    <Brush
                                        dataKey="week"
                                        height={22}
                                        stroke="#6366f1"
                                        fill="#0f172a"
                                        tickFormatter={formatWeek}
                                        className="text-[9px] font-mono"
                                        travellerWidth={10}
                                    />
                                )}

                                {keys.map(key => {
                                    const isOtherHovered = hoveredLine && hoveredLine !== key;

                                    return (
                                        <Bar
                                            key={`delta_${key}`}
                                            dataKey={`delta_${key}`}
                                            name={`${activeKeys[key].name} (Var.)`}
                                            fill={activeKeys[key].color}
                                            radius={[4, 4, 4, 4]}
                                            hide={hiddenKeys[key]}
                                            fillOpacity={isOtherHovered ? 0.4 : 1}
                                            style={{ transition: 'all 0.3s ease' }}
                                        >
                                            {chartData.map((entry, index) => {
                                                const barColor = entry[`deltaColor_${key}`] || '#94a3b8';
                                                return <Cell key={`cell-${index}`} fill={barColor} fillOpacity={isOtherHovered ? 0.4 : 0.85} />;
                                            })}
                                        </Bar>
                                    );
                                })}
                            </BarChart>
                        )}
                    </ResponsiveContainer>
                )}
            </div>

            {viewMode === 'variation' && (
                <div className="mt-4 rounded-2xl border border-rose-500/25 bg-rose-950/20 backdrop-blur-sm p-4 shadow-sm">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-rose-300 mb-2.5 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse"></span> Principais quedas na semana
                    </p>
                    {topRegressions.length > 0 ? (
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                            {topRegressions.map(item => (
                                <div key={item.key} className="rounded-xl bg-slate-950/60 border border-white/10 px-3 py-2 text-[10px] flex items-center justify-between min-w-0 gap-2 shadow-inner">
                                    <span className="truncate min-w-0 font-bold" style={{ color: item.color }} title={item.fullName}>{item.name}</span>
                                    <span className="font-mono font-black text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/20">{formatValue(item.delta)}{unit}</span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="text-slate-400 text-xs text-center py-3">Nenhuma queda visível no filtro atual. ✅</p>
                    )}
                </div>
            )}

            {viewMode !== 'performance' && (
                <div className="flex justify-center mt-3 opacity-60">
                    <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest bg-slate-900 px-3 py-1 rounded-md border border-slate-800 shrink-0 select-none">
                        💡 Dica: clique nos itens da legenda para ocultar ou isolar o gráfico.
                    </p>
                </div>
            )}
        </div>
    );
};

