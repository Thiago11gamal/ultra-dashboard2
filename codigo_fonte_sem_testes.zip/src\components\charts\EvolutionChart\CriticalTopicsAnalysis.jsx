import React, { useState, useMemo } from 'react';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
    ResponsiveContainer, LabelList, Cell
} from "recharts";
import { normalizeDate, getDateKey } from "../../../utils/dateHelper";
import { getSafeScore, getSyntheticTotal } from "../../../utils/scoreHelper";
import { toArray, getHistoryDate } from "../../../utils/evolutionGuards";

const CustomTooltipStyle = {
    backgroundColor: 'rgba(15, 23, 42, 0.9)',
    backdropFilter: 'blur(16px)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '12px',
    padding: '12px 16px',
    fontSize: '12px',
    boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
};

// Mover para top-level (antes do componente)
const WEEKS = [
    { label: "Semana 4", offset: 4 },
    { label: "Semana 3", offset: 3 },
    { label: "Semana 2", offset: 2 },
    { label: "Semana 1", offset: 1 },
    { label: "Semana atual", offset: 0 },
];

import { ShieldAlert, AlertTriangle, Sparkles } from "lucide-react";

export const CriticalTopicsAnalysis = React.memo(({ categories = [], maxScore = 100, minScore = 0 }) => {
    const [selectedWeekOffset, setSelectedWeekOffset] = useState(0);

    // Calc time window
    const { startDate, endDate, startDateKey, endDateKey, dateLabel } = useMemo(() => {
        const end = new Date();
        end.setHours(23, 59, 59, 999);
        end.setDate(end.getDate() - (selectedWeekOffset * 7));

        const start = new Date(end);
        start.setHours(0, 0, 0, 0);
        start.setDate(end.getDate() - 6);

        const format = (d) => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;

        return {
            startDate: start,
            endDate: end,
            startDateKey: getDateKey(start),
            endDateKey: getDateKey(end),
            dateLabel: `${format(start)} — ${format(end)}`
        };
    }, [selectedWeekOffset]);

    const subtopicsData = useMemo(() => {
        if (!categories || !categories.length) return [];
        const topicMap = {};

        categories.forEach(cat => {
            const historyRaw = cat.simuladoStats?.history;
            const history = Array.isArray(historyRaw) ? historyRaw : Object.values(historyRaw || {});
            if (!history.length) return;

            const recentHistory = history.filter(h => {
                const k = getDateKey(getHistoryDate(h));
                return k && k >= startDateKey && k <= endDateKey;
            });

            const catMax = Number(cat.maxScore) > 0 ? Number(cat.maxScore) : (Number(maxScore) || 100);
            const catMin = Number.isFinite(Number(cat.minScore)) ? Number(cat.minScore) : (Number(minScore) || 0);
            const catRange = Math.max(1e-9, catMax - catMin);
            if (!Number.isFinite(catRange) || catRange <= 0) return;
            for (let i = 0; i < recentHistory.length; i++) {
                const h = recentHistory[i];
                let topicList = toArray(h.topics);
                if (topicList.length === 0 && (h.topic || h.assunto || h.subtopic || h.topicName)) {
                    topicList = [{
                        name: h.topic || h.assunto || h.subtopic || h.topicName,
                        total: h.total ?? h.questoes ?? h.totalQuestoes ?? h.questions,
                        correct: h.correct ?? h.acertos ?? h.correctCount,
                        score: h.score,
                        isPercentage: h.isPercentage
                    }];
                }

                topicList.forEach(t => {
                    const n = String(t.name || '').replace(/^\[(.*?)\]\s*/i, '').replace(/<[^>]*>?/gm, '').trim();
                    if (!n || n.toLowerCase() === 'nenhum') return;
                    const key = n.toLowerCase();
                    if (!topicMap[key]) topicMap[key] = { name: n, total: 0, correct: 0, criticidade: 0 };

                    let total = parseInt(t.total ?? t.questoes ?? t.totalQuestoes ?? t.questions, 10) || 0;
                    if (total === 0 && t.score != null) {
                        total = getSyntheticTotal(catMax);
                    } else if (total === 0) {
                        return;
                    }
                    
                    if (total <= 0) return;
                    const hasExplicitCorrect = !t.isPercentage && (
                        (t.correct !== null && t.correct !== undefined && String(t.correct).trim() !== '') ||
                        (t.acertos !== null && t.acertos !== undefined && String(t.acertos).trim() !== '') ||
                        (t.correctCount !== null && t.correctCount !== undefined && String(t.correctCount).trim() !== '')
                    );
                    const parsedCorrect = Number(t.correct ?? t.acertos ?? t.correctCount);
                    let correctCount;
                    if (hasExplicitCorrect && Number.isFinite(parsedCorrect)) {
                        correctCount = parsedCorrect;
                    } else {
                        const score = getSafeScore(t, catMax, catMin);
                        if (!Number.isFinite(score)) return;
                        const normalizedScore = Math.max(catMin, Math.min(catMax, score));
                        correctCount = ((normalizedScore - catMin) / catRange) * total;
                    }

                    if (!Number.isFinite(correctCount)) return;
                    const safeCorrect = Math.max(0, Math.min(total, correctCount));

                    topicMap[key].total += total;
                    topicMap[key].correct += safeCorrect;
                });
            }
        });

        // Calcular criticidade final consolidada por tópico
        Object.keys(topicMap).forEach(key => {
            const item = topicMap[key];
            const accuracy = item.total > 0 ? item.correct / item.total : 0;
            const erroAbsoluto = item.total - item.correct;
            // Índice de criticidade
            item.criticidade = erroAbsoluto * (1 - accuracy);
        });

        const PALETTE = ["#ef4444", "#f97316", "#fb923c", "#f59e0b", "#facc15"];
        const result = Object.values(topicMap)
            .filter(d => Math.round(d.criticidade * 10) > 0)
            .sort((a, b) => b.criticidade - a.criticidade);

        return result.slice(0, 15).map((item, i, arr) => {
            const isLong = item.name.length > 34;
            return {
                ...item,
                name: isLong ? item.name.substring(0, 32) + '...' : item.name,
                fullName: item.name,
                value: Math.round(item.criticidade * 10) / 10,
                fill: PALETTE[Math.min(PALETTE.length - 1, Math.floor((i / (arr.length > 1 ? arr.length - 1 : 1)) * (PALETTE.length - 1)))]
            };
        });
    }, [categories, startDateKey, endDateKey, maxScore, minScore]);

    const pointLeakageData = useMemo(() => {
        if (!categories || !categories.length) return [];
        let totalCriticidade = 0;
        const PALETTE = ["#ef4444", "#f97316", "#fb923c", "#f59e0b", "#facc15"];

        const rawData = categories.map(cat => {
            let total = 0;
            let correct = 0;
            const historyRaw = cat.simuladoStats?.history;
            const history = Array.isArray(historyRaw) ? historyRaw : Object.values(historyRaw || {});

            const recentHistory = history.filter(h => {
                const k = getDateKey(getHistoryDate(h));
                return k && k >= startDateKey && k <= endDateKey;
            });
            const catMax = Number(cat.maxScore) > 0 ? Number(cat.maxScore) : (Number(maxScore) || 100);
            const catMin = Number.isFinite(Number(cat.minScore)) ? Number(cat.minScore) : (Number(minScore) || 0);
            const catRange = Math.max(1e-9, catMax - catMin);
            for (const h of recentHistory) {
                let t = parseInt(h.total ?? h.questoes ?? h.totalQuestoes ?? h.questions, 10) || 0;
                if (t === 0 && h.score != null) {
                    t = getSyntheticTotal(catMax);
                } else if (t === 0) {
                    let topicList = toArray(h.topics);
                    if (topicList.length === 0 && (h.topic || h.assunto || h.subtopic || h.topicName)) {
                        topicList = [{
                            name: h.topic || h.assunto || h.subtopic || h.topicName,
                            total: h.total ?? h.questoes ?? h.totalQuestoes ?? h.questions,
                            correct: h.correct ?? h.acertos ?? h.correctCount,
                            score: h.score,
                            isPercentage: h.isPercentage
                        }];
                    }
                    // Fallback: agrega a partir de h.topics se o cabeçalho h não tiver total/score
                    topicList.forEach(tp => {
                        let tpTot = parseInt(tp.total ?? tp.questoes ?? tp.totalQuestoes ?? tp.questions, 10) || 0;
                        if (tpTot === 0 && tp.score != null) tpTot = getSyntheticTotal(catMax);
                        if (tpTot <= 0) return;
                        const hasTpCorr = !tp.isPercentage && (
                            (tp.correct !== null && tp.correct !== undefined && String(tp.correct).trim() !== '') ||
                            (tp.acertos !== null && tp.acertos !== undefined && String(tp.acertos).trim() !== '') ||
                            (tp.correctCount !== null && tp.correctCount !== undefined && String(tp.correctCount).trim() !== '')
                        );
                        const parsedTpCorr = Number(tp.correct ?? tp.acertos ?? tp.correctCount);
                        let tpCorr;
                        if (hasTpCorr && Number.isFinite(parsedTpCorr)) {
                            tpCorr = parsedTpCorr;
                        } else {
                            const tpScore = getSafeScore(tp, catMax, catMin);
                            if (!Number.isFinite(tpScore)) return;
                            tpCorr = ((Math.max(catMin, Math.min(catMax, tpScore)) - catMin) / catRange) * tpTot;
                        }
                        if (Number.isFinite(tpCorr)) {
                            total += tpTot;
                            correct += Math.max(0, Math.min(tpTot, tpCorr));
                        }
                    });
                    continue;
                }
                
                const hasExplicitCorrect = !h.isPercentage && (
                    (h.correct !== null && h.correct !== undefined && String(h.correct).trim() !== '') ||
                    (h.acertos !== null && h.acertos !== undefined && String(h.acertos).trim() !== '') ||
                    (h.correctCount !== null && h.correctCount !== undefined && String(h.correctCount).trim() !== '')
                );
                const parsedHCorrect = Number(h.correct ?? h.acertos ?? h.correctCount);
                let correctCount;
                if (hasExplicitCorrect && Number.isFinite(parsedHCorrect)) {
                    correctCount = parsedHCorrect;
                } else {
                    const score = getSafeScore(h, catMax, catMin);
                    if (!Number.isFinite(score)) continue;
                    const normalizedScore = Math.max(catMin, Math.min(catMax, score));
                    correctCount = ((normalizedScore - catMin) / catRange) * t;
                }
                
                if (!Number.isFinite(correctCount)) continue;
                const safeCorrect = Math.max(0, Math.min(t, correctCount));
                total += t;
                correct += safeCorrect;
            }
            
            const accuracy = total > 0 ? correct / total : 0;
            const erroAbsoluto = total - correct;
            const criticidade = erroAbsoluto * (1 - accuracy);
            
            return { name: cat.name, value: criticidade, errors: erroAbsoluto };
        });

        const data = rawData.filter(d => Math.round(d.value * 10) > 0).sort((a, b) => b.value - a.value);
        data.forEach(d => { totalCriticidade += d.value; });

        return data.slice(0, 10).map((item, i, arr) => {
            const isLong = item.name.length > 24;
            return {
                ...item,
                fullName: item.name,
                name: isLong ? item.name.substring(0, 22) + '...' : item.name,
                color: PALETTE[Math.min(PALETTE.length - 1, Math.floor((i / (arr.length > 1 ? arr.length - 1 : 1)) * (PALETTE.length - 1)))],
                percentage: totalCriticidade > 0 ? Math.round((item.value / totalCriticidade) * 100) : 0,
                displayValue: Math.round(item.value * 10) / 10
            };
        });
    }, [categories, startDateKey, endDateKey, maxScore, minScore]);

    const hasData = useMemo(() => {
      if (!categories) return false;
    
      return categories.some(cat => {
        const historyRaw = cat.simuladoStats?.history;
        const history = Array.isArray(historyRaw)
          ? historyRaw
          : Object.values(historyRaw || {});
    
        return history.some(h => {
          const k = getDateKey(getHistoryDate(h));
          const topics = toArray(h.topics);
    
          const hasTopicData = topics.some(
            t => Number(t.total) > 0 || t.score != null
          );
    
          return (
            k &&
            k >= startDateKey &&
            k <= endDateKey &&
            (
              parseInt(h.total, 10) > 0 ||
              h.score != null ||
              hasTopicData
            )
          );
        });
      });
    }, [categories, startDateKey, endDateKey]);

    const weekTitle = WEEKS.find(w => w.offset === selectedWeekOffset)?.label || "SEMANA";

    return (
        <div className="w-full space-y-4 pt-2">
            {/* Header com Navegação Temporal Unificada */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md shadow-lg">
                <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 shadow-inner shrink-0">
                        <ShieldAlert size={20} />
                    </div>
                    <div>
                        <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-sm sm:text-base font-bold text-white">Matriz de criticidade e pontos de fuga</h3>
                            <span className="px-2 py-0.5 rounded-full bg-rose-500/10 text-[9px] font-black text-rose-400 border border-rose-500/20 uppercase tracking-wider">
                                Índice de Criticidade
                            </span>
                        </div>
                        <p className="text-[11px] sm:text-xs text-slate-400 font-medium">
                            Identifique matérias e assuntos específicos que mais geram perdas de pontos
                        </p>
                    </div>
                </div>

                {/* Week Selector + Date Range Badge */}
                <div className="flex flex-wrap items-center gap-2 self-start md:self-center shrink-0">
                    <div className="flex items-center gap-1 overflow-x-auto no-scrollbar p-1 bg-slate-950/80 rounded-xl border border-slate-800/80 shadow-inner">
                        {WEEKS.map((w) => {
                            const isActive = selectedWeekOffset === w.offset;
                            return (
                                <button
                                    key={w.label}
                                    type="button"
                                    onClick={() => setSelectedWeekOffset(w.offset)}
                                    aria-pressed={isActive}
                                    className={`px-3 py-1.5 text-[9px] sm:text-[10px] font-black uppercase tracking-wider rounded-xl transition-all ${
                                        isActive
                                            ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-[0_0_15px_rgba(99,102,241,0.5)] border border-indigo-400/50'
                                            : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                                    }`}
                                >
                                    {w.label}
                                </button>
                            );
                        })}
                    </div>
                    <div className="text-[10px] sm:text-[11px] font-mono font-bold text-indigo-300 bg-indigo-950/60 border border-indigo-700/50 px-3 py-1.5 rounded-xl shadow-inner">
                        {dateLabel}
                    </div>
                </div>
            </div>

            {/* Painéis Lado a Lado perfeitamente enquadrados */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 sm:gap-6 items-stretch">
                {/* Matérias críticas */}
                <div className="rounded-3xl border border-slate-800/80 bg-slate-900/60 backdrop-blur-md p-4 sm:p-6 shadow-xl hover:border-slate-700/80 transition-all flex flex-col justify-between h-full min-w-0">
                    <div>
                        <div className="flex items-center justify-between gap-2 mb-1">
                            <p className="text-[10px] sm:text-xs text-slate-400 font-bold uppercase tracking-wider">{weekTitle}</p>
                            <span className="text-[9px] font-black text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                                {pointLeakageData.length} {pointLeakageData.length === 1 ? 'matéria' : 'matérias'}
                            </span>
                        </div>
                        <h4 className="text-sm sm:text-base font-black text-slate-100 mb-1 flex items-center gap-2 tracking-tight">
                            🩸 Matérias Críticas
                        </h4>
                        <p className="text-[10px] sm:text-xs text-slate-400 mb-4 leading-relaxed">
                            Disciplinas com maior Índice de Criticidade (Erros acumulados × taxa de erro).
                        </p>
                    </div>

                    <div className="min-h-[220px] sm:min-h-[260px] w-full flex-1 flex flex-col justify-center">
                        {pointLeakageData.length > 0 ? (
                            <ResponsiveContainer width="100%" height={Math.max(220, pointLeakageData.length * 38)} minWidth={1}>
                                <BarChart data={pointLeakageData} layout="vertical" margin={{ top: 5, right: 85, left: -5, bottom: 5 }}>
                                    <CartesianGrid stroke="rgba(255,255,255,0.05)" horizontal={false} />
                                    <XAxis type="number" stroke="#94a3b8" tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 600 }} axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} tickLine={false} allowDecimals={false} />
                                    <YAxis type="category" dataKey="fullName" tickFormatter={(v) => String(v || '').length > 24 ? `${String(v).slice(0, 22)}...` : v} stroke="#cbd5e1" tick={{ fontSize: 10, fill: '#cbd5e1', fontWeight: 600 }} axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} tickLine={false} width={160} />
                                    <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)', radius: 6 }} formatter={(v, n, props) => [`${v} pts (Índice)`, `${props?.payload?.fullName || 'Matéria'} (${props?.payload?.errors || 0} erros)`]} contentStyle={CustomTooltipStyle} itemStyle={{ color: '#e2e8f0' }} />
                                    <Bar dataKey="displayValue" radius={[0, 8, 8, 0]} barSize={18} minPointSize={4}>
                                        {pointLeakageData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                                        <LabelList dataKey="displayValue" position="right" offset={8}
                                            content={(props) => {
                                                const { x, y, width, value, index } = props;
                                                const entry = pointLeakageData[index];
                                                if (!entry || value === null || value === undefined) return null;
                                                return (
                                                    <text x={x + width + 8} y={y + 11} fill="#ffffff" fontSize={10.5} fontWeight="bold">
                                                        {value}{entry.percentage > 0 ? ` (${entry.percentage}%)` : ''}
                                                    </text>
                                                );
                                            }}
                                        />
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        ) : (
                            <div className="h-full min-h-[220px] flex flex-col items-center justify-center bg-slate-950/30 rounded-2xl border border-slate-800/50 p-6 text-slate-500 text-sm text-center">
                                <span className="text-4xl mb-2">{hasData ? '🎉' : '⏳'}</span>
                                <p className="font-bold text-slate-300 mb-1">{hasData ? 'Sem erros críticos!' : 'Nenhum dado registrado'}</p>
                                <p className="text-xs text-slate-400 mt-0.5">{hasData ? 'Nenhum erro crítico registrado nesta semana.' : 'Sem simulados registrados neste período. Selecione outra semana acima.'}</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Assuntos críticos */}
                <div className="rounded-3xl border border-slate-800/80 bg-slate-900/60 backdrop-blur-md p-4 sm:p-6 shadow-xl hover:border-slate-700/80 transition-all flex flex-col justify-between h-full min-w-0">
                    <div>
                        <div className="flex items-center justify-between gap-2 mb-1">
                            <p className="text-[10px] sm:text-xs text-slate-400 font-bold uppercase tracking-wider">{weekTitle} · TODOS OS ASSUNTOS</p>
                            <span className="text-[9px] font-black text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                                {subtopicsData.length} {subtopicsData.length === 1 ? 'tópico' : 'tópicos'}
                            </span>
                        </div>
                        <h4 className="text-sm sm:text-base font-black text-slate-100 mb-1 flex items-center gap-2 tracking-tight">
                            📏 Assuntos Críticos
                        </h4>
                        <p className="text-[10px] sm:text-xs text-slate-400 mb-4 leading-relaxed">
                            Tópicos com maior urgência de revisão e reforço teórico.
                        </p>
                    </div>

                    <div className="min-h-[220px] sm:min-h-[260px] w-full flex-1 flex flex-col justify-center">
                        {subtopicsData.length > 0 ? (
                            <ResponsiveContainer width="100%" height={Math.max(220, subtopicsData.length * 38)} minWidth={1}>
                                <BarChart data={subtopicsData} layout="vertical" margin={{ top: 5, right: 65, left: -5, bottom: 5 }}>
                                    <CartesianGrid stroke="rgba(255,255,255,0.05)" horizontal={false} />
                                    <XAxis type="number" stroke="#94a3b8" tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 600 }} axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} tickLine={false} allowDecimals={false} />
                                    <YAxis type="category" dataKey="fullName" tickFormatter={(v) => String(v || '').length > 34 ? `${String(v).slice(0, 32)}...` : v} stroke="#cbd5e1" tick={{ fontSize: 10, fill: '#cbd5e1', fontWeight: 600 }} axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} tickLine={false} width={160} />
                                    <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)', radius: 6 }} formatter={(v, n, props) => {
                                        const total = Number(props?.payload?.total) || 0;
                                        const correct = Math.round(Number(props?.payload?.correct) || 0);
                                        const errors = Math.max(0, total - correct);
                                        return [`${v} (Índice)`, `${props?.payload?.fullName || 'Assunto'} (${errors} erros)`];
                                    }} contentStyle={CustomTooltipStyle} itemStyle={{ color: '#e2e8f0' }} />
                                    <Bar dataKey="value" radius={[0, 8, 8, 0]} barSize={18} minPointSize={4}>
                                        {subtopicsData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                                        <LabelList dataKey="value" position="right" style={{ fill: '#ffffff', fontSize: 10.5, fontWeight: 'bold' }} offset={8} />
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        ) : (
                            <div className="h-full min-h-[220px] flex flex-col items-center justify-center bg-slate-950/30 rounded-2xl border border-slate-800/50 p-6 text-slate-500 text-sm text-center">
                                <span className="text-4xl mb-2">{hasData ? '🎉' : '⏳'}</span>
                                <p className="font-bold text-slate-300 mb-1">{hasData ? 'Sem assuntos críticos!' : 'Nenhum dado registrado'}</p>
                                <p className="text-xs text-slate-400 mt-0.5">{hasData ? 'Nenhum erro registrado neste período.' : 'Sem simulados registrados neste período. Selecione outra semana acima.'}</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
});

