import { useState, useEffect, useRef } from 'react';
import { db, isLocalMode } from '../services/firebase';
import { collection, query, where, onSnapshot, doc } from 'firebase/firestore';

export function useSubscription(user) {
  const adminEmails = (import.meta.env.VITE_ADMIN_EMAILS || 'antunest040@gmail.com')
    .split(',')
    .map(e => e.trim().toLowerCase());
  const userEmail = (user?.email || '').trim().toLowerCase();
  const isAdminEmail = Boolean(userEmail && (userEmail === 'antunest040@gmail.com' || adminEmails.includes(userEmail)));

  const isDevBypass = import.meta.env.VITE_DEV_PREMIUM_BYPASS === 'true' || isLocalMode || user?.uid === 'local-user' || isAdminEmail;

  const [isPremium, setIsPremium] = useState(isDevBypass);
  const [loading, setLoading] = useState(!isDevBypass);
  const fallbackUnsubRef = useRef(null);

  useEffect(() => {
    if (isDevBypass || isAdminEmail) {
        const t = setTimeout(() => {
            setIsPremium(true);
            setLoading(false);
        }, 0);
        return () => clearTimeout(t);
    }
    
    if (!user?.uid) { 
        const t = setTimeout(() => {
            setIsPremium(false); 
            setLoading(false); 
        }, 0);
        return () => clearTimeout(t);
    }
    
    let unsub = null;
    let isMounted = true;

    try {
      if (typeof user.getIdTokenResult !== 'function') {
        setTimeout(() => {
          if (!isMounted) return;
          setIsPremium(true);
          setLoading(false);
        }, 0);
        return;
      }
      // Ler claims do token JWT (definidas server-side via Cloud Functions)
      user.getIdTokenResult(true).then((tokenResult) => {
        if (!isMounted) return;
        const claims = tokenResult.claims || {};
        const isAdminClaim = Boolean(claims.admin || claims.premium || claims.plan === 'vitalicio');
        
        if (isAdminClaim) {
            setIsPremium(true);
            setLoading(false);
            return;
        }

        // Se não for admin claim, verificar pagamentos (Stripe)
        if (!db) {
            setIsPremium(false);
            setLoading(false);
            return;
        }

        const paymentsRef = collection(db, 'customers', user.uid, 'payments');
        const q = query(paymentsRef, where('status', '==', 'succeeded'));

        if (!isMounted) return;
        unsub = onSnapshot(q, (snapshot) => {
            if (!isMounted) return;
            if (snapshot.empty) {
                setIsPremium(false);
                setLoading(false);
                return;
            }

            let hasValidPayment = false;
            snapshot.forEach((paymentDoc) => {
                const data = paymentDoc.data();
                if (data.status === 'succeeded') {
                    hasValidPayment = true;
                }
            });

            setIsPremium(hasValidPayment);
            setLoading(false);
        }, (error) => {
            if (!isMounted) return;
            console.error('[Stripe] Erro ao buscar pagamentos:', error);

            if (error?.code === 'permission-denied') {
                const userRef = doc(db, 'users', user.uid);
                if (!isMounted) return;
                fallbackUnsubRef.current = onSnapshot(userRef, (userDoc) => {
                    if (!isMounted) return;
                    const profile = userDoc.exists() ? userDoc.data() : {};
                    const premiumFromProfile = Boolean(
                        profile?.isPremium
                        || profile?.premium
                        || profile?.subscription?.active,
                    );
                    setIsPremium(premiumFromProfile);
                    setLoading(false);
                }, (_profileErr) => {
                    if (!isMounted) return;
                    setIsPremium(false);
                    setLoading(false);
                });
                if (!isMounted && fallbackUnsubRef.current) {
                    fallbackUnsubRef.current();
                    fallbackUnsubRef.current = null;
                }
                return;
            }

            setIsPremium(false);
            setLoading(false);
        });

        if (!isMounted && unsub) {
            unsub();
            unsub = null;
        }

      }).catch(() => { 
          if (!isMounted) return;
          setIsPremium(false); 
          setLoading(false); 
      });
    } catch {
      setTimeout(() => {
        if (!isMounted) return;
        setIsPremium(false);
        setLoading(false);
      }, 0);
    }

    return () => { 
        isMounted = false;
        if (unsub) unsub(); 
        if (fallbackUnsubRef.current) {
            fallbackUnsubRef.current();
            fallbackUnsubRef.current = null;
        }
    };
  }, [user, isDevBypass, isAdminEmail]);

  if (isDevBypass) return { isPremium: true, loading: false };
  if (!user?.uid) return { isPremium: false, loading: false };
  if (!db) {
      console.warn('[Stripe] Firestore indisponível. Mantendo modo não premium.');
      return { isPremium: false, loading: false };
  }

  return { isPremium, loading };
}

