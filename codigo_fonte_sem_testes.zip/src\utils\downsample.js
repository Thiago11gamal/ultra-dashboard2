import { toDateMs } from './dateHelper.js';

export function downsampleLTTB(data, threshold, xKey, yKey) {
  if (!data || !Array.isArray(data) || data.length === 0) {
    return data || [];
  }
  const safeThreshold = Math.max(3, Math.floor(Number(threshold) || data.length));
  if (data.length <= safeThreshold) {
    return data;
  }
  const getX = (item) => {
    const val = item[xKey];
    if (typeof val === "string" && val.includes("-")) {
      return toDateMs(val);
    }
    return Number(val) || 0;
  };
  const getY = (item) => Number(item[yKey]) || 0;
  const dataLength = data.length;
  const bucketSize = (dataLength - 2) / (safeThreshold - 2);
  let a = 0;
  const sampledData = [data[0]];
  for (let i = 0; i < safeThreshold - 2; i++) {
    let avgX = 0;
    let avgY = 0;
    let avgRangeStart = Math.floor((i + 1) * bucketSize) + 1;
    let avgRangeEnd = Math.floor((i + 2) * bucketSize) + 1;
    avgRangeEnd = avgRangeEnd < dataLength ? avgRangeEnd : dataLength;
    const avgRangeLength = avgRangeEnd - avgRangeStart;
    for (; avgRangeStart < avgRangeEnd; avgRangeStart++) {
      avgX += getX(data[avgRangeStart]);
      avgY += getY(data[avgRangeStart]);
    }
    if (avgRangeLength > 0) {
      avgX /= avgRangeLength;
      avgY /= avgRangeLength;
    } else if (avgRangeStart < dataLength) {
      avgX = getX(data[avgRangeStart]);
      avgY = getY(data[avgRangeStart]);
    }
    let rangeOffs = Math.floor(i * bucketSize) + 1;
    let rangeTo = Math.floor((i + 1) * bucketSize) + 1;
    const pointAx = getX(data[a]);
    const pointAy = getY(data[a]);
    let maxArea = -1;
    let maxAreaIndex = -1;
    for (; rangeOffs < rangeTo; rangeOffs++) {
      const bx = getX(data[rangeOffs]);
      const by = getY(data[rangeOffs]);
      const area = Math.abs((pointAx - avgX) * (by - pointAy) - (pointAx - bx) * (avgY - pointAy)) * 0.5;
      if (area > maxArea) {
        maxArea = area;
        maxAreaIndex = rangeOffs;
      }
    }
    // ── FIX: bucket vazio não pode injetar undefined na série ──
    if (maxAreaIndex === -1) {
      maxAreaIndex = Math.min(rangeTo - 1, dataLength - 1);
    }

    sampledData.push(data[maxAreaIndex]);
    a = maxAreaIndex;
  }
  sampledData.push(data[dataLength - 1]);
  return sampledData;
}
