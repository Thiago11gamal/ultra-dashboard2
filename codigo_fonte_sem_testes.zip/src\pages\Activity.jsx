import { PageErrorBoundary } from '../components/ErrorBoundary';
import React, { useState } from 'react';
import { CalendarDays, RotateCcw, Trophy, Target, BookOpen } from 'lucide-react';
import { StreakDisplay, XPHistory, AchievementsGrid } from '../components/GamificationComponents';
import ActivityHeatmap from '../components/ActivityHeatmap';
import { useAppStore } from '../store/useAppStore';
import { useToast } from '../hooks/useToast';
import { buildAchievementStats } from '../utils/analytics';
import ConfirmModal from '../components/ConfirmModal';

export default function Activity() {
    const data = useAppStore(state => state.appState?.contests?.[state.appState?.activeId] || null);
    const setData = useAppStore(state => state.setData);
    const showToast = useToast();
    const [showResetModal, setShowResetModal] = useState(false);
    
    const achievementStats = React.useMemo(
        () => buildAchievementStats(data) || {},
        [data]
    );

    if (!data) {
        return <div className="flex items-center justify-center p-12 text-slate-400">A carregar dados gamificados...</div>;
    }

    const studyLogsArray = Array.isArray(data?.studyLogs) ? data.studyLogs : Object.values(data?.studyLogs || {});

    const handleResetXP = () => {
        setData(prev => ({
            ...(prev || {}),
            user: {
                ...(prev?.user || {}),
                xp: 0,
                level: 1,
                achievements: [],
                streak: 0,
                // BUG-T05 FIX: Registrar timestamp do reset para que
                // buildAchievementStats não re-desbloqueie conquistas
                // antigas baseadas em dados que já existiam antes do reset.
                achievementsResetAt: new Date().toISOString()
            }
        }));
        setShowResetModal(false);
        showToast('Nível, XP e Troféus Resetados!', 'success');
    };

    return (<PageErrorBoundary pageName="Heatmap">
        <div className="space-y-8 animate-fade-in pb-10">
            <ConfirmModal
                isOpen={showResetModal}
                onClose={() => setShowResetModal(false)}
                onConfirm={handleResetXP}
                title="Resetar Dados Gamificados"
                message="Atenção: Isto vai apagar todo o seu XP e Nível atual. Suas tarefas e histórico de estudos continuarão intactos."
                confirmText="Confirmar Reset"
                type="danger"
                icon={RotateCcw}
            />

            {/* Cabeçalho Premium */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 bg-slate-900/30 p-6 rounded-3xl border border-white/5 backdrop-blur-sm">
                <div className="space-y-2">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-2xl border border-indigo-500/30 shadow-inner">
                            <Trophy size={28} className="text-indigo-400" />
                        </div>
                        <h1 className="text-3xl md:text-4xl font-extrabold bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent tracking-tight">
                            Central de Atividade
                        </h1>
                    </div>
                    <p className="text-slate-400 ml-16 text-sm font-medium">Sua jornada de evolução, consistência e conquistas.</p>
                </div>

                <button
                    onClick={() => setShowResetModal(true)}
                    className="group flex items-center justify-center gap-2 px-5 py-2.5 bg-slate-800/40 hover:bg-red-500/10 text-slate-400 hover:text-red-400 border border-slate-700 hover:border-red-500/30 rounded-xl transition-all duration-300 text-sm font-semibold shadow-sm"
                >
                    <RotateCcw size={16} className="group-hover:-rotate-180 transition-transform duration-500" />
                    Resetar Progresso
                </button>
            </div>

            {/* Grid Principal: Layout inteligente e distribuído */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

                {/* Coluna da Esquerda: Streak e XP (Ocupa 4/12 colunas) */}
                <div className="lg:col-span-4 flex flex-col gap-6">
                    <div className="bg-slate-900/50 backdrop-blur-xl border border-white/5 rounded-3xl p-2 shadow-xl hover:border-white/10 transition-all">
                        <StreakDisplay studyLogs={studyLogsArray} />
                    </div>
                    <div className="bg-slate-900/50 backdrop-blur-xl border border-white/5 rounded-3xl p-2 shadow-xl hover:border-white/10 transition-all flex-1">
                        <XPHistory user={data.user} />
                    </div>
                </div>

                {/* Coluna da Direita: Mapa de Calor (Calendário) (Ocupa 8/12 colunas) */}
                <div className="lg:col-span-8 flex flex-col">
                    <div className="bg-gradient-to-b from-slate-800/40 to-slate-900/60 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl flex-1 flex flex-col relative transition-all duration-500 hover:border-white/20 hover:shadow-[0_0_30px_rgba(99,102,241,0.1)]">
                        {/* Brilho decorativo isolado para não dar clip (overflow-hidden) nos Tooltips das laterais */}
                        <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
                            <div className="absolute -top-10 -right-10 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl transition-all duration-700 hover:bg-indigo-500/20" />
                        </div>

                        <div className="p-6 relative z-10 flex flex-col flex-1">
                            <div className="flex items-center gap-3 mb-6">
                                <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-500/20">
                                    <CalendarDays size={22} className="text-emerald-400" />
                                </div>
                                <div>
                                    <h2 className="text-xl font-bold text-slate-100">Mapa de Frequência</h2>
                                    <p className="text-xs text-slate-400 mt-0.5">Seu histórico de dedicação ao longo do tempo</p>
                                </div>
                            </div>

                            {/* Ajuste importante: overflow visível para tooltips mas mantendo o inner shadow */}
                            <div className="flex-1 w-full bg-slate-950/40 rounded-2xl p-6 border border-white/5 shadow-inner">
                                <ActivityHeatmap studyLogs={studyLogsArray} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Flashcards como Medidas e Indicadores */}
            {achievementStats && (achievementStats.flashcardReviews > 0 || achievementStats.flashcardDecks > 0) && (
                <div className="glass border border-amber-500/20 bg-amber-950/5 rounded-3xl p-6">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-amber-500/10 rounded-xl border border-amber-500/20">
                            <BookOpen size={20} className="text-amber-400" />
                        </div>
                        <div>
                            <h3 className="text-lg font-black text-white tracking-tight">Flashcards — Medidas e Indicadores</h3>
                            <p className="text-xs text-amber-400/70 uppercase">Volume, precisão e retenção via SRS</p>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-center">
                        <div>
                            <div className="text-xs text-slate-500 tracking-widest">REVISÕES</div>
                            <div className="text-3xl font-black text-amber-300">{achievementStats.flashcardReviews || 0}</div>
                        </div>
                        <div>
                            <div className="text-xs text-slate-500 tracking-widest">PRECISÃO</div>
                            <div className="text-3xl font-black text-emerald-400">{(achievementStats.flashcardAccuracy || 0).toFixed(0)}<span className="text-base">%</span></div>
                        </div>
                        <div>
                            <div className="text-xs text-slate-500 tracking-widest">HOJE</div>
                            <div className="text-3xl font-black text-white">{achievementStats.flashcardReviewsToday || 0}</div>
                        </div>
                        <div>
                            <div className="text-xs text-slate-500 tracking-widest">DECKS</div>
                            <div className="text-3xl font-black text-white">{achievementStats.flashcardDecks || 0}</div>
                        </div>
                        <div>
                            <div className="text-xs text-slate-500 tracking-widest">PENDENTES</div>
                            <div className="text-3xl font-black text-orange-400">{achievementStats.flashcardDueToday || 0}</div>
                        </div>
                    </div>
                </div>
            )}

            {/* Seção Inferior: Galeria de Troféus */}
            <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl relative transition-all hover:border-white/20">
                {/* Isolando o overflow-hidden apenas para o brilho decorativo para não cortar os Tooltips */}
                <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
                    <div className="absolute -left-32 -bottom-32 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
                </div>

                <div className="p-8 relative z-10">
                    <div className="flex items-center gap-3 mb-8">
                        <div className="p-2.5 bg-amber-500/20 rounded-xl border border-amber-500/20">
                            <Target size={22} className="text-amber-400" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold text-slate-100">Galeria de Troféus</h2>
                            <p className="text-sm text-slate-400 mt-1">Insígnias de desafios completados e marcos alcançados</p>
                        </div>
                    </div>

                    <div>
                        <AchievementsGrid
                            unlockedIds={data.user?.achievements || []}
                            stats={achievementStats}
                        />
                    </div>
                </div>
            </div>
        </div>
    </PageErrorBoundary>);
}

