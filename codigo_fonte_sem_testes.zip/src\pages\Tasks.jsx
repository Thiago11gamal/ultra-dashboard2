import { PageErrorBoundary } from '../components/ErrorBoundary';
import React, { useState } from 'react';
import PersonalRanking from '../components/PersonalRanking';
import VolumeRanking from '../components/VolumeRanking';
import PerformanceTable from '../components/PerformanceTable';
import SubtopicsTable from '../components/SubtopicsTable';
import { useAppStore } from '../store/useAppStore';
import { useShallow } from 'zustand/react/shallow';
import { RotateCcw } from 'lucide-react';
import { useToast } from '../hooks/useToast';
import ConfirmModal from '../components/ConfirmModal';

export default function Tasks() {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const rawCategories = useAppStore(useShallow(state => {
    const activeId = state.appState?.activeId || 'default';
    const activeContest = state.appState?.contests?.[activeId];
    return activeContest?.categories || [];
  }));

  const categories = React.useMemo(() => {
    const list = (Array.isArray(rawCategories) ? rawCategories : Object.values(rawCategories || {})).filter(Boolean);
    return list.map(c => ({
      ...c,
      tasks: Array.isArray(c?.tasks) ? c.tasks : Object.values(c?.tasks || {})
    }));
  }, [rawCategories]);
  
  const resetSimuladoStats = useAppStore(state => state.resetSimuladoStats);
  const showToast = useToast();
  
  const maxScore = React.useMemo(() => {
    const scores = categories.map(c => Number(c?.maxScore)).filter(s => Number.isFinite(s) && s > 0);
    return scores.length > 0 ? scores.reduce((a, b) => Math.max(a, b), -Infinity) : 100;
  }, [categories]);

  const minScore = React.useMemo(() => {
    const scores = categories.map(c => Number(c?.minScore)).filter(s => Number.isFinite(s));
    return scores.length > 0 ? scores.reduce((a, b) => Math.min(a, b), Infinity) : 0;
  }, [categories]);
  
  const handleResetConfirm = () => {
    resetSimuladoStats();
    showToast('Resetado com sucesso!', 'success');
  };

  if (categories.length === 0) {
    return (
      <PageErrorBoundary pageName="Tarefas">
        <div className="min-h-[50vh] flex items-center justify-center text-center px-4">
          <div>
            <p className="text-slate-300 font-bold uppercase tracking-wider text-xs">Sem tarefas cadastradas</p>
            <p className="text-slate-500 text-[11px] mt-1">Crie matérias e tarefas para liberar rankings e quadros de performance.</p>
          </div>
        </div>
      </PageErrorBoundary>
    );
  }

  return (
    <PageErrorBoundary pageName="Tarefas">
      <div className="space-y-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          <div className="lg:col-span-2">
            <PersonalRanking categories={categories} />
          </div>
          <div className="lg:col-span-1 h-full">
            <VolumeRanking categories={categories} />
          </div>
        </div>
        
        <div className="pb-8 border-t border-white/5 pt-10 mt-10">
          <h2 className="text-2xl font-bold mb-10 flex items-center gap-3">
            📊 Quadro de Performance
            <button
              onClick={() => setShowResetConfirm(true)}
              className="p-1.5 rounded-lg bg-slate-800/50 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Resetar dados do quadro"
            >
              <RotateCcw size={16} />
            </button>
          </h2>
          
          <PerformanceTable categories={categories} maxScore={maxScore} minScore={minScore} />
          <SubtopicsTable categories={categories} maxScore={maxScore} minScore={minScore} />
        </div>
      </div>

      <ConfirmModal
        isOpen={showResetConfirm}
        onClose={() => setShowResetConfirm(false)}
        onConfirm={handleResetConfirm}
        title="Resetar Performance"
        message="Tem certeza que deseja resetar os dados de estatística do quadro de performance?"
        confirmText="Resetar Dados"
        type="warning"
        icon={RotateCcw}
      />
    </PageErrorBoundary>
  );
}
