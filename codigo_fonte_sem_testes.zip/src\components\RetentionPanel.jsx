import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { BrainCircuit, Clock, AlertTriangle, CheckCircle2, TrendingDown, Zap, Calendar, ChevronDown, BookOpen, Play, Info } from 'lucide-react';
import { formatTimeAgo } from '../utils/dateHelper';
import { formatValue } from '../utils/scoreHelper';
import {
    clamp,
    normalizeArray,
    toDateMs,
    getMasterySignal,
    halfLifeFromMastery,
    getLatestStudyMs,
    MS_PER_DAY
} from '../utils/retentionCore';

// Calculate retention based on Ebbinghaus Forgetting Curve
const calculateRetention = (lastStudiedAt, halfLife = 7, now = Date.now()) => {
    const safeHalfLife = Math.max(1e-6, Number(halfLife) || 7);

    if (!lastStudiedAt) {
        return {
            val: 0,
            status: 'never',
            label: 'Nunca estudado',
            color: 'text-slate-400',
            bg: 'bg-slate-500',
            border: 'border-slate-500/30'
        };
    }

    const last = toDateMs(lastStudiedAt);

    if (last == null || Number.isNaN(last)) {
        return {
            val: 0,
            status: 'never',
            label: 'Não Estudado',
            color: 'text-slate-400',
            bg: 'bg-slate-500',
            border: 'border-slate-500/30'
        };
    }

    const days = Math.max(0, (now - last) / MS_PER_DAY);

    if (!Number.isFinite(days)) {
        return {
            val: 0,
            status: 'never',
            label: 'Não Estudado',
            color: 'text-slate-400',
            bg: 'bg-slate-500',
            border: 'border-slate-500/30'
        };
    }

    const val = clamp(
        Math.round(100 * Math.exp(-Math.LN2 * days / safeHalfLife)),
        0,
        100
    );

    if (val >= 80) {
        return {
            val,
            status: 'fresh',
            label: 'Ótimo',
            color: 'text-emerald-400',
            bg: 'bg-emerald-500',
            border: 'border-emerald-500/30'
        };
    }

    if (val >= 60) {
        return {
            val,
            status: 'good',
            label: 'Bom',
            color: 'text-green-400',
            bg: 'bg-green-500',
            border: 'border-green-500/30'
        };
    }

    if (val >= 40) {
        return {
            val,
            status: 'warning',
            label: 'Atenção',
            color: 'text-yellow-400',
            bg: 'bg-yellow-500',
            border: 'border-yellow-500/30'
        };
    }

    if (val >= 20) {
        return {
            val,
            status: 'danger',
            label: 'Crítico',
            color: 'text-orange-400',
            bg: 'bg-orange-500',
            border: 'border-orange-500/30'
        };
    }

    return {
        val,
        status: 'critical',
        label: 'Urgente!',
        color: 'text-red-400',
        bg: 'bg-red-500',
        border: 'border-red-500/30'
    };
};

// Format time ago removido porque já existe no dateHelper

// Retention Ring Component
const RetentionRing = ({ value, size = 48, strokeWidth = 3, color }) => {
    const safeValue = Math.max(0, Math.min(100, Number(value) || 0));
    const radius = (size - strokeWidth) / 2;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (safeValue / 100) * circumference;

    return (
        <div className="relative" style={{ width: size, height: size }}>
            <svg className="w-full h-full -rotate-90" aria-hidden="true">
                <circle
                    cx={size / 2}
                    cy={size / 2}
                    r={radius}
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={strokeWidth}
                    className="text-slate-700/50"
                />
                <circle
                    cx={size / 2}
                    cy={size / 2}
                    r={radius}
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={strokeWidth}
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    className={color}
                    style={{ transition: 'stroke-dashoffset 0.5s ease' }}
                />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
                <span className={`text-xs font-bold ${color}`}>{formatValue(safeValue)}%</span>
            </div>
        </div>
    );
};

// Mini retention bar for topics
const RetentionBar = ({ value, bg }) => (
    <div
        className="w-16 h-1.5 bg-slate-700 rounded-full overflow-hidden"
        role="progressbar"
        aria-valuenow={Math.max(0, Math.min(100, Number(value) || 0))}
        aria-valuemin="0"
        aria-valuemax="100"
        aria-label="Retenção do tópico"
    >
        <div
            className={`h-full rounded-full transition-all duration-500 ${bg}`}
            style={{ width: `${Math.max(0, Math.min(100, Number(value) || 0))}%` }}
        />
    </div>
);

export default function RetentionPanel({ categories = [], onSelectCategory }) {
    const [expandedCategories, setExpandedCategories] = useState({});

    // Auto-refresh now every 60 seconds to recalculate retention
    const [now, setNow] = useState(() => Date.now());

    useEffect(() => {
        const interval = setInterval(() => {
            if (!document.hidden) setNow(Date.now());
        }, 60000);

        const handleVisibilityChange = () => {
            if (!document.hidden) setNow(Date.now());
        };

        document.addEventListener('visibilitychange', handleVisibilityChange);

        return () => {
            clearInterval(interval);
            document.removeEventListener('visibilitychange', handleVisibilityChange);
        };
    }, []);

    const toggleExpand = (catId) => {
        setExpandedCategories(prev => ({
            ...prev,
            [catId]: !prev[catId]
        }));
    };

    // Helper to get style from value - moved before useMemo that uses it
    const getRetentionStyle = useCallback((val) => {
        if (val >= 80) return { status: 'fresh', label: 'Ótimo', color: 'text-emerald-400', bg: 'bg-emerald-500', border: 'border-emerald-500/30', bgLight: 'bg-emerald-500/10', bgHover: 'hover:bg-emerald-500/40', ringHover: 'hover:ring-emerald-400/50', shadow: 'shadow-emerald-500/10' };
        if (val >= 60) return { status: 'good', label: 'Bom', color: 'text-green-400', bg: 'bg-green-500', border: 'border-green-500/30', bgLight: 'bg-green-500/10', bgHover: 'hover:bg-green-500/40', ringHover: 'hover:ring-green-400/50', shadow: 'shadow-green-500/10' };
        if (val >= 40) return { status: 'warning', label: 'Atenção', color: 'text-yellow-400', bg: 'bg-yellow-500', border: 'border-yellow-500/30', bgLight: 'bg-yellow-500/10', bgHover: 'hover:bg-yellow-500/40', ringHover: 'hover:ring-yellow-400/50', shadow: 'shadow-yellow-500/10' };
        if (val >= 20) return { status: 'danger', label: 'Crítico', color: 'text-orange-400', bg: 'bg-orange-500', border: 'border-orange-500/30', bgLight: 'bg-orange-500/10', bgHover: 'hover:bg-orange-500/40', ringHover: 'hover:ring-orange-400/50', shadow: 'shadow-orange-500/10' };
        return { status: 'critical', label: 'Urgente!', color: 'text-red-400', bg: 'bg-red-500', border: 'border-red-500/30', bgLight: 'bg-red-500/10', bgHover: 'hover:bg-red-500/40', ringHover: 'hover:ring-red-400/50', shadow: 'shadow-red-500/10' };
    }, []);

    // Calculate retention for all categories and their tasks
    const retentionData = useMemo(() => {
        const safeCategories = normalizeArray(categories);

        return safeCategories
            .filter(cat => cat && (cat.id || cat.name))
            .map(cat => {
                const safeCategoryName = String(cat.name || 'Sem nome');

                const catMastery = getMasterySignal(cat);
                const catHalfLife = halfLifeFromMastery(catMastery.masterySignal);

                const rawTasks = normalizeArray(cat.tasks);

                const tasksWithRetention = rawTasks
                    .map(task => {
                        const taskMastery = getMasterySignal(task, cat);
                        const taskHalfLife = 7 + (16 * taskMastery.masterySignal);
                        const lastStudy = task.lastStudiedAt ?? task.completedAt;

                        return {
                            ...task,
                            retention: calculateRetention(lastStudy, taskHalfLife, now),
                            timeAgo: formatTimeAgo(lastStudy)
                        };
                    })
                    .sort((a, b) => a.retention.val - b.retention.val);

                const studiedTasks = tasksWithRetention.filter(task => task.retention.status !== 'never');

                const avgTaskRetention = studiedTasks.length > 0
                    ? Math.round(studiedTasks.reduce((acc, task) => acc + task.retention.val, 0) / studiedTasks.length)
                    : null;

                const latestStudyMs = getLatestStudyMs(cat, rawTasks);
                const catDirectRet = calculateRetention(latestStudyMs, catHalfLife, now);
                const isNeverStudied = catDirectRet.status === 'never' && studiedTasks.length === 0;

                let finalVal = catDirectRet.val;

                if (avgTaskRetention !== null) {
                    const coverage = studiedTasks.length / Math.max(1, tasksWithRetention.length);
                    const blended = Math.round((avgTaskRetention * 0.7) + (catDirectRet.val * 0.3));
                    const coveragePenalty = Math.round((1 - coverage) * 20);
                    finalVal = clamp(blended - coveragePenalty, 0, 100);
                }

                const categoryRetention = isNeverStudied
                    ? { val: 0, status: 'never', label: 'Não Estudado', color: 'text-slate-500', bg: 'bg-slate-800', border: 'border-slate-700', bgLight: 'bg-slate-800/10', bgHover: 'hover:bg-slate-800/40', ringHover: 'hover:ring-slate-400/50', shadow: 'shadow-slate-500/10' }
                    : { val: finalVal, ...getRetentionStyle(finalVal) };

                return {
                    ...cat,
                    name: safeCategoryName,
                    retention: categoryRetention,
                    timeAgo: formatTimeAgo(latestStudyMs),
                    tasksWithRetention,
                    criticalTasks: tasksWithRetention.filter(task => task.retention.status !== 'never' && task.retention.val < 40).length,
                    warningTasks: tasksWithRetention.filter(task => task.retention.status !== 'never' && task.retention.val >= 40 && task.retention.val < 60).length,
                    neverTasks: tasksWithRetention.filter(task => task.retention.status === 'never').length
                };
            })
            .sort((a, b) => a.retention.val - b.retention.val);
    }, [categories, now, getRetentionStyle]); // now forces periodic recalculation

    // Stats summary
    const stats = useMemo(() => {
        // Count all tasks across all categories
        const allTasks = retentionData.reduce((acc, cat) => acc.concat(cat.tasksWithRetention), []);

        const critical = allTasks.filter(t => t.retention.val < 40 && t.retention.status !== 'never').length;
        const warning = allTasks.filter(t => t.retention.val >= 40 && t.retention.val < 60 && t.retention.status !== 'never').length;
        const healthy = allTasks.filter(t => t.retention.val >= 60).length;

        // FIX: Ignorar tarefas 'never' no cálculo da média global
        const studiedTasks = allTasks.filter(t => t.retention.status !== 'never');
        const avgRetention = studiedTasks.length > 0
            ? Math.round(studiedTasks.reduce((acc, t) => acc + t.retention.val, 0) / studiedTasks.length)
            : 0;
        return { critical, warning, healthy, avgRetention, totalTasks: allTasks.length, studiedTasks: studiedTasks.length, totalCategories: retentionData.length };
    }, [retentionData]);

    // Get priority items (need review)
    const needsReview = useMemo(() => {
        const urgent = retentionData.reduce((acc, cat) => {
            const urgentTasks = cat.tasksWithRetention
                .filter(task => task.retention.val < 60 && task.retention.status !== 'never')
                .map(task => ({ ...task, categoryName: cat.name, categoryIcon: cat.icon, categoryColor: cat.color, catReference: cat }));
            return acc.concat(urgentTasks);
        }, []);
        return urgent.sort((a, b) => a.retention.val - b.retention.val);
    }, [retentionData]);

    return (
        <div className="w-full space-y-8 pt-10 pb-12 animate-fade-in-down">
            {/* Header */}
            <div className="flex items-center gap-5 px-1">
                <div className="relative">
                    <div className="absolute inset-0 bg-purple-500/30 rounded-2xl blur-xl"></div>
                    <div className="relative p-3.5 bg-gradient-to-br from-purple-500/20 to-indigo-500/20 rounded-2xl border border-purple-500/30">
                        <BrainCircuit size={32} className="text-purple-400" />
                    </div>
                </div>
                <div>
                    <h2 className="text-2xl font-black bg-gradient-to-r from-white via-white to-slate-400 bg-clip-text text-transparent uppercase tracking-tight flex items-center">
                        Painel de Retenção
                        <div className="relative group/tooltip cursor-help ml-3 inline-flex mt-1">
                            <Info size={16} className="text-slate-500/50 hover:text-slate-400 transition-colors" />
                            <div className="absolute top-full left-0 mt-2 w-72 p-3 bg-slate-900/95 backdrop-blur-md text-xs text-slate-300 rounded-xl shadow-2xl opacity-0 invisible group-hover/tooltip:opacity-100 group-hover/tooltip:visible transition-all duration-300 z-[60] pointer-events-none border border-slate-700/80 font-normal tracking-normal normal-case leading-relaxed">
                                <strong className="text-white">Retenção (Ebbinghaus):</strong> Calcula o quanto de um assunto você ainda lembra baseado em quando foi a última revisão. Revisar antes do nível "Atenção" (abaixo de 60%) ajuda a fixar o conteúdo na memória de longo prazo.
                            </div>
                        </div>
                    </h2>
                    <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mt-0.5 opacity-80">
                        Baseado na Curva de Esquecimento de Ebbinghaus
                    </p>
                </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Average Retention */}
                <div className="glass p-4 border-l-4 border-purple-500 relative group hover:border-purple-400 transition-all duration-500 min-h-[135px]">
                    <div className="absolute inset-0 rounded-[1.25rem] overflow-hidden pointer-events-none">
                        <BrainCircuit size={70} className="absolute -right-4 -bottom-4 text-purple-500/10 group-hover:text-purple-500/20 transition-all duration-700" />
                    </div>
                    <div className="relative z-10 h-full flex flex-col justify-between">
                        <div>
                            <div className="flex items-center gap-2 text-slate-500 text-[10px] font-black uppercase tracking-[0.15em] mb-2">
                                <BrainCircuit size={12} className="text-purple-500" />
                                Média Geral
                            </div>
                            <div className="text-4xl font-black text-white mb-2 tracking-tighter">{stats.avgRetention}%</div>
                        </div>

                        <div>
                            {/* Progress Bar */}
                            <div className="h-1.5 bg-slate-950/50 rounded-full overflow-hidden mb-2 border border-white/5" role="progressbar" aria-valuenow={stats.avgRetention} aria-valuemin="0" aria-valuemax="100">
                                <div className="h-full bg-gradient-to-r from-purple-600 to-purple-400 rounded-full shadow-[0_0_8px_rgba(168,85,247,0.4)]" style={{ width: `${stats.avgRetention}%` }} />
                            </div>
                            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">{stats.totalTasks} assuntos</div>
                        </div>
                    </div>
                </div>

                {/* Critical */}
                <div className="glass p-4 border-l-4 border-red-500 relative group hover:border-red-400 transition-all duration-500 min-h-[135px]">
                    <div className="absolute inset-0 rounded-[1.25rem] overflow-hidden pointer-events-none">
                        <AlertTriangle size={70} className="absolute -right-4 -bottom-4 text-red-500/10 group-hover:text-red-500/20 transition-all duration-700" />
                    </div>
                    <div className="relative z-10 h-full flex flex-col justify-between">
                        <div>
                            <div className="flex items-center gap-2 text-slate-500 text-[10px] font-black uppercase tracking-[0.15em] mb-2">
                                <AlertTriangle size={12} className="text-red-500" />
                                Críticos
                            </div>
                            <div className="text-4xl font-black text-red-400 tracking-tighter">{stats.critical}</div>
                        </div>
                        <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-1">
                            precisam de revisão
                        </div>
                    </div>
                </div>

                {/* Warning */}
                <div className="glass p-4 border-l-4 border-yellow-500 relative group hover:border-yellow-400 transition-all duration-500 min-h-[135px]">
                    <div className="absolute inset-0 rounded-[1.25rem] overflow-hidden pointer-events-none">
                        <TrendingDown size={70} className="absolute -right-4 -bottom-4 text-yellow-500/10 group-hover:text-yellow-500/20 transition-all duration-700" />
                    </div>
                    <div className="relative z-10 h-full flex flex-col justify-between">
                        <div>
                            <div className="flex items-center gap-2 text-slate-500 text-[10px] font-black uppercase tracking-[0.15em] mb-2">
                                <TrendingDown size={12} className="text-yellow-500" />
                                Atenção
                            </div>
                            <div className="text-4xl font-black text-yellow-500 tracking-tighter">{stats.warning}</div>
                        </div>
                        <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-1">
                            em declínio
                        </div>
                    </div>
                </div>

                {/* Healthy */}
                <div className="glass p-4 border-l-4 border-emerald-500 relative group hover:border-emerald-400 transition-all duration-500 min-h-[135px]">
                    <div className="absolute inset-0 rounded-[1.25rem] overflow-hidden pointer-events-none">
                        <CheckCircle2 size={70} className="absolute -right-4 -bottom-4 text-emerald-500/10 group-hover:text-emerald-500/20 transition-all duration-700" />
                    </div>
                    <div className="relative z-10 h-full flex flex-col justify-between">
                        <div>
                            <div className="flex items-center gap-2 text-slate-500 text-[10px] font-black uppercase tracking-[0.15em] mb-2">
                                <CheckCircle2 size={12} className="text-emerald-500" />
                                Saudáveis
                            </div>
                            <div className="text-4xl font-black text-emerald-400 tracking-tighter">{stats.healthy}</div>
                        </div>
                        <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-1">
                            excelente
                        </div>
                    </div>
                </div>
            </div>

            {/* Priority Alert Box */}
            {needsReview.length > 0 && (
                <div className="relative rounded-2xl overflow-hidden shadow-2xl group">
                    <div className="absolute inset-0 bg-gradient-to-br from-red-950/60 via-slate-900/40 to-orange-950/40"></div>
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_0%_0%,rgba(239,68,68,0.15),transparent_50%)] transition-opacity duration-700 group-hover:opacity-60"></div>
                    <div className="relative p-7 border border-red-500/20 rounded-2xl">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                            <div className="flex items-center gap-4">
                                <div className="p-3 bg-red-500/10 rounded-2xl border border-red-500/20 shadow-inner">
                                    <Zap size={24} className="text-red-400 drop-shadow-[0_0_8px_rgba(239,68,68,0.4)]" />
                                </div>
                                <div>
                                    <h3 className="text-base font-black text-red-400 uppercase tracking-[0.1em]">
                                        Revisão Necessária
                                    </h3>
                                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">
                                        {needsReview.length} {needsReview.length > 1 ? 'tópicos' : 'tópico'} com retenção abaixo de 60%
                                    </p>
                                </div>
                            </div>

                            <div className="flex flex-wrap gap-2 md:justify-end max-w-xl">
                                {needsReview.slice(0, 5).map((task, index) => (
                                    <div
                                        key={task.id || `${task.title}-${index}`}
                                        onClick={() => typeof onSelectCategory === 'function' && onSelectCategory({ ...task.catReference, selectedTask: task })}
                                        className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-[10px] font-black border transition-all duration-300 hover:scale-105 cursor-pointer ${task.retention.border} ${task.retention.color} bg-black/40 backdrop-blur-sm`}
                                    >
                                        <span className="opacity-70">{task.categoryIcon}</span>
                                        <span className="uppercase tracking-tight break-words line-clamp-2">{task.title || task.text || 'Sem nome'}</span>
                                        <span className="ml-1 bg-white/5 px-1.5 py-0.5 rounded-md">{formatValue(task.retention.val)}%</span>
                                    </div>
                                ))}
                                {needsReview.length > 5 && (
                                    <div className="px-3 py-1.5 rounded-xl text-[10px] font-black text-slate-500 bg-slate-950/60 border border-white/5 uppercase tracking-widest">
                                        +{needsReview.length - 5} mais
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Categories List with Expandable Topics */}
            <div className="bg-slate-950/40 backdrop-blur-xl rounded-2xl border border-white/5 overflow-hidden shadow-2xl">
                <div className="p-7 border-b border-white/5 bg-slate-900/30">
                    <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 flex items-center gap-3">
                        <div className="p-1.5 rounded-lg bg-slate-800 text-slate-400">
                            <Calendar size={14} />
                        </div>
                        Matérias & Tópicos de Estudo
                        <span className="ml-auto text-[10px] lowercase font-medium opacity-60">
                            ({stats.totalCategories} matérias, {stats.totalTasks} assuntos)
                        </span>
                    </h3>
                </div>

                <div className="divide-y divide-white/[0.03]">
                    {retentionData.length === 0 ? (
                        <div className="flex flex-col items-center justify-center p-20 opacity-20">
                            <BrainCircuit size={48} className="text-slate-500 mb-4" />
                            <span className="text-sm font-black uppercase tracking-widest">Nenhuma matéria encontrada</span>
                        </div>
                    ) : (
                        retentionData.map((cat) => {
                            const isExpanded = expandedCategories[cat.id];
                            const hasTasks = cat.tasksWithRetention.length > 0;

                            return (
                                <div key={cat.id} className="transition-all duration-500">
                                    {/* Category Header */}
                                    <div
                                        className={`group p-6 cursor-pointer transition-all duration-500 hover:bg-white/[0.02]
                                            ${cat.retention.val < 40
                                                ? 'bg-gradient-to-r from-red-500/[0.03] to-transparent'
                                                : cat.retention.val < 60
                                                    ? 'bg-gradient-to-r from-yellow-500/[0.02] to-transparent'
                                                    : ''
                                            }`}
                                        onClick={() => hasTasks && toggleExpand(cat.id)}
                                    >
                                        <div className="flex items-center gap-6">
                                            {/* Icon */}
                                            <div
                                                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shrink-0 transition-transform duration-500 group-hover:scale-110 shadow-lg border border-white/5"
                                                style={{ backgroundColor: `${cat.color}15`, borderColor: `${cat.color}30` }}
                                            >
                                                {cat.icon}
                                            </div>

                                            {/* Info */}
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center gap-3 mb-1.5">
                                                    <h4 className="text-base font-black text-white uppercase tracking-tight break-words line-clamp-2">{cat.name}</h4>
                                                    <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest shadow-sm ${cat.retention.bgLight} ${cat.retention.color} border ${cat.retention.border}`}>
                                                        {cat.retention.label === 'Urgente!' ? 'Crítico' : cat.retention.label}
                                                    </span>
                                                    {cat.criticalTasks > 0 && (
                                                        <span className="px-2 py-0.5 rounded-lg text-[9px] font-black bg-red-500/10 text-red-500 border border-red-500/20 shadow-sm uppercase tracking-tighter">
                                                            {cat.criticalTasks} {cat.criticalTasks > 1 ? 'críticos' : 'crítico'}
                                                        </span>
                                                    )}
                                                </div>
                                                <div className="flex items-center gap-4 text-[10px] text-slate-500 font-bold uppercase tracking-widest opacity-80">
                                                    <span className="flex items-center gap-1.5">
                                                        <BookOpen size={12} className="text-slate-600" />
                                                        {cat.tasksWithRetention.length} assuntos
                                                    </span>
                                                    <span className="text-slate-800">•</span>
                                                    <span className="flex items-center gap-1.5 focus:text-slate-300 transition-colors">
                                                        <Clock size={12} className="text-slate-600" />
                                                        {cat.timeAgo === 'Nunca' ? 'Inédito' : cat.timeAgo}
                                                    </span>
                                                </div>
                                            </div>

                                            {/* Retention Ring Container */}
                                            <div className="flex items-center gap-6">
                                                <div className="hidden sm:block">
                                                    <RetentionRing
                                                        value={cat.retention.val}
                                                        color={cat.retention.color}
                                                    />
                                                </div>

                                                {/* Expand Arrow */}
                                                {hasTasks && (
                                                    <div className={`p-2 rounded-xl bg-slate-900 border border-white/5 transition-all duration-500 ${isExpanded ? 'rotate-180 bg-slate-800 border-white/10' : ''}`}>
                                                        <ChevronDown size={18} className="text-slate-500" />
                                                    </div>
                                                )}
                                            </div>
                                        </div>

                                        {/* Progress Bar Mini */}
                                        <div className="mt-5 h-1.5 bg-slate-950/50 rounded-full overflow-hidden border border-white/5">
                                            <div
                                                className={`h-full rounded-full transition-all duration-1000 ${cat.retention.bg} shadow-[0_0_8px_rgba(0,0,0,0.3)]`}
                                                style={{ width: `${cat.retention.val}%` }}
                                            ></div>
                                        </div>
                                    </div>

                                    {/* Expanded Topics Container */}
                                    {isExpanded && hasTasks && (
                                        <div className="bg-black/20 border-t border-white/5 animate-fade-in-down">
                                            <div className="p-4 space-y-2">
                                                {cat.tasksWithRetention.map((task, index) => (
                                                    <div
                                                        key={task.id || `${task.title}-${index}`}
                                                        className={`flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 hover:bg-white/[0.03] group/item border border-transparent hover:border-white/5
                                                            ${task.retention.val < 40 ? 'bg-red-500/[0.03]' : task.retention.val < 60 ? 'bg-yellow-500/[0.02]' : ''}`}
                                                        onClick={() => typeof onSelectCategory === 'function' && onSelectCategory({ ...cat, selectedTask: task })}
                                                    >
                                                        {/* Task Icon Circle */}
                                                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm shrink-0 transition-transform group-hover/item:scale-110 shadow-lg ${task.retention.bgLight} ${task.retention.color} border ${task.retention.border}`}>
                                                            <BookOpen size={16} />
                                                        </div>

                                                        {/* Task Info */}
                                                        <div className="flex-1 min-w-0">
                                                            <p className="text-sm font-black text-slate-200 uppercase tracking-tight break-words line-clamp-2">{task.title || task.text || 'Sem nome'}</p>
                                                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">
                                                                {task.timeAgo === 'Nunca' ? 'Aguardando estudo' : `Última revisão: ${task.timeAgo}`}
                                                            </p>
                                                        </div>

                                                        {/* Percentage & Bar */}
                                                        <div className="flex items-center gap-6">
                                                            <div className="hidden md:block">
                                                                <RetentionBar value={task.retention.val} color={task.retention.color} bg={task.retention.bg} />
                                                            </div>
                                                            <span className={`text-sm font-black font-mono ${task.retention.color} w-10 text-right`}>
                                                                {formatValue(task.retention.val)}%
                                                            </span>
                                                        </div>

                                                        {/* Play Button - Action */}
                                                        <button
                                                            onClick={(e) => { e.stopPropagation(); if (typeof onSelectCategory === 'function') onSelectCategory({ ...cat, selectedTask: task }); }}
                                                            className={`w-10 h-10 rounded-xl flex items-center justify-center border transition-all hover:text-white hover:ring-2 hover:scale-110 group/play ${task.retention.bgLight} ${task.retention.border} ${task.retention.color} ${task.retention.bgHover} ${task.retention.ringHover} ${task.retention.shadow}`}
                                                            title="Iniciar Revisão"
                                                        >
                                                            <Play size={18} className={`translate-x-[1px] transition-all drop-shadow-md fill-current opacity-50 group-hover/play:opacity-100`} />
                                                        </button>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            );
                        })
                    )}
                </div>
            </div>

            {/* Footer Tip */}
            <div className="bg-slate-900/40 p-5 rounded-2xl border border-white/5 text-center flex items-center justify-center gap-3">
                <div className="w-8 h-8 rounded-full bg-yellow-500/10 flex items-center justify-center border border-yellow-500/20 text-yellow-500">
                    <Zap size={14} className="animate-pulse" />
                </div>
                <p className="text-[11px] font-black uppercase tracking-widest text-slate-500">
                    Dica: <span className="text-slate-300">Clique em uma matéria para expandir os tópicos. Priorize revisões abaixo de 60%.</span>
                </p>
            </div>
        </div>
    );
}

