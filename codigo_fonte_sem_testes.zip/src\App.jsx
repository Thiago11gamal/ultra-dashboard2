import React, { useState, useEffect, Suspense, useCallback, useRef } from 'react';
import { motion as Motion } from 'framer-motion';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import ErrorBoundary from './components/ErrorBoundary';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Login from './components/Login';
import HelpGuide from './components/HelpGuide';
import Toast from './components/Toast';
import { lazyWithRetry } from './utils/lazyRetry';

// ✅ FIX P01: Importação Tardia (Lazy Loading) de Modais e Componentes Pesados
// Movemos LevelUpToast, OnboardingTour e TrashModal para fora do bundle principal.
const LevelUpToast = lazyWithRetry(() => import('./components/LevelUpToast'));
const OnboardingTour = lazyWithRetry(() => import('./components/OnboardingTour'));
const TrashModal = lazyWithRetry(() => import('./components/TrashModal'));
// WelcomeScreen não pode ser lazy porque precisa bloquear a interface no primeiro render
import WelcomeScreen from './components/WelcomeScreen';

// Página Principal (Dashboard) - Lazy Loading para otimizar o bundle inicial
const Dashboard = lazyWithRetry(() => import('./pages/Dashboard'));

// Páginas pesadas com carregamento diferido (Lazy Loading)
const Pomodoro = lazyWithRetry(() => import('./pages/Pomodoro'));
const Tasks = lazyWithRetry(() => import('./pages/Tasks'));
const Simulados = lazyWithRetry(() => import('./pages/Simulados'));
const Stats = lazyWithRetry(() => import('./pages/Stats'));
const Evolution = lazyWithRetry(() => import('./pages/Evolution'));
const Coach = lazyWithRetry(() => import('./pages/Coach'));
const History = lazyWithRetry(() => import('./pages/History'));
const Activity = lazyWithRetry(() => import('./pages/Activity'));
const Retention = lazyWithRetry(() => import('./pages/Retention'));
const Notes = lazyWithRetry(() => import('./pages/Notes'));
const Sessions = lazyWithRetry(() => import('./pages/Sessions'));
const Flashcards = lazyWithRetry(() => import('./pages/Flashcards'));
const Agenda = lazyWithRetry(() => import('./pages/Agenda'));
const Paywall = lazyWithRetry(() => import('./components/Paywall'));

import { useAuth } from './context/useAuth';
import { useSubscription } from './hooks/useSubscription';
import { useAppStore, useTemporalStore } from './store/useAppStore';
import { useShallow } from 'zustand/react/shallow';
import { useCloudSync } from './hooks/useCloudSync';
import { useToast } from './hooks/useToast';

import { useGlobalToasts } from './hooks/useGlobalToasts';
import { useLevelUp } from './hooks/useLevelUp';
import { useThemeSync } from './hooks/useThemeSync';
import { parseImportedData } from './utils/backupManager';
import { exportData } from './data/initialData';
import useIdleLogout from './hooks/useIdleLogout';
import { stopCleanup } from './hooks/useMonteCarloWorker';



import './components/Loading.css';

const EMPTY_OBJECT = Object.freeze({});

const RootRedirect = () => {
  const { currentUser } = useAuth();

  useEffect(() => {
    if (currentUser) {
      const intentionalDashboard = sessionStorage.getItem('navigateToDashboard');
      if (intentionalDashboard) {
        sessionStorage.removeItem('navigateToDashboard');
        localStorage.removeItem(`lastRoute_${currentUser.uid}`);
      }
    }
  }, [currentUser]);

  if (currentUser) {
    // Se o usuário clicou explicitamente em "Meu Painel", não redirecionar
    const intentionalDashboard = sessionStorage.getItem('navigateToDashboard');
    if (intentionalDashboard) {
      return <Dashboard />;
    }
    const lastRoute = localStorage.getItem(`lastRoute_${currentUser.uid}`);
    if (lastRoute && lastRoute !== '/') {
      return <Navigate to={lastRoute} replace />;
    }
  }
  return <Dashboard />;
};

function MainLayout() {
  const location = useLocation();
  const { currentUser, loading, logout } = useAuth();

  useEffect(() => {
    if (currentUser && location.pathname !== '/' && location.pathname !== '/login') {
      localStorage.setItem(`lastRoute_${currentUser.uid}`, location.pathname + location.search);
    }
  }, [location, currentUser]);
  const { isPremium, loading: subLoading } = useSubscription(currentUser);

  const activeContestId = useAppStore(state => state.appState?.activeId);

  // P11 PERF FIX: Use useShallow inline with useAppStore for stable selectors
  const contestsMetaList = useAppStore(useShallow(state => {
    const contests = state.appState?.contests || {};
    return Object.keys(contests).reduce((acc, key) => {
      acc[key] = contests[key]?.contestName || contests[key]?.name || contests[key]?.user?.name || (key === 'default' ? 'Estudante' : 'Novo Concurso');
      return acc;
    }, {});
  }));

  const headerData = useAppStore(useShallow(state => {
    const activeId = state.appState?.activeId;
    const contest = state.appState?.contests?.[activeId];
    return {
      exists: !!contest,
      user: contest?.user,
      settings: contest?.settings
    };
  }));

  const syncTrigger = useAppStore(useShallow(state => ({
    version: state.appState?.version,
    lastUpdated: state.appState?.lastUpdated
  })));


  const setAppState = useAppStore(state => state.setAppState);
  const switchContest = useAppStore(state => state.switchContest);
  const createNewContest = useAppStore(state => state.createNewContest);
  const deleteContest = useAppStore(state => state.deleteContest);
  const updateUserName = useAppStore(state => state.updateUserName);
  const undo = useTemporalStore(state => state.undo);

  const importTimeoutRef = useRef(null);

  // Custom Hooks para lógica global
    const { toasts, removeToast } = useGlobalToasts();
    const { levelUpData, clearLevelUp } = useLevelUp();
    const showToast = useToast();

  // --- AUTO-LOGOUT (60 MIN INACTIVITY) ---
  // BUG-FIX: Increased from 20 to 60 to safely handle Pomodoro sessions (25m + break)
  useIdleLogout(logout, 60 * 60 * 1000);

  // Handle cross-tab sync using real-time listener inside sync context
  const [showHelpGuide, setShowHelpGuide] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(true);
  const [trashOpen, setTrashOpen] = useState(false);
  const rescueAttemptsRef = useRef(0);

  // P12 PERF FIX: Stable callbacks to avoid invalidating React.memo on Sidebar/Header
  const handleOpenHelp = useCallback(() => setShowHelpGuide(true), []);
  const handleCloseHelp = useCallback(() => setShowHelpGuide(false), []);
  const handleToggleSidebar = useCallback(() => setIsSidebarOpen(prev => !prev), []);
  const handleOpenTrash = useCallback(() => setTrashOpen(true), []);
  const handleCloseTrash = useCallback(() => setTrashOpen(false), []);
  const handleCloseMobile = useCallback(() => setIsSidebarOpen(false), []);
  
  // Controle da tela de Boas-Vindas (Premium) - Aparece 1x por sessão (login)
  // ── ESTADO DA TELA DE BOAS-VINDAS ──
  const [showWelcome, setShowWelcome] = useState(() => {
      // Verifica se a tela de boas-vindas já foi vista nesta sessão
      const hasSeen = sessionStorage.getItem('hasSeenWelcomeScreen');
      return !hasSeen;
  });

  const handleDismissWelcome = useCallback(() => {
      sessionStorage.setItem('hasSeenWelcomeScreen', 'true');
      setShowWelcome(false);
  }, []);

  // Garante que se o usuário fizer logout (voltar para a tela de login), 
  // o estado reseta para mostrar o WelcomeScreen no próximo login.
  useEffect(() => {
      if (!loading && !currentUser) {
          sessionStorage.removeItem('hasSeenWelcomeScreen');
          // eslint-disable-next-line
          setShowWelcome(true);
      }
  }, [currentUser, loading]);
  // ───────────────────────────────────

  // Flag reativa da Store para garantir hidratação atômica
  const isStoreHydrated = useAppStore(state => state.appState.isHydrated);

  // Auto-save pipeline
  const { cloudStatus, cloudError, isSyncing: isCloudSyncing, hasConflict, forcePullCloud } = useCloudSync(
    isStoreHydrated ? currentUser : null,
    setAppState,
    showToast,
    syncTrigger // Pass trigger to notify hook of changes (version/lastUpdated)
  );

  // --- THEME SYNC ---
  useThemeSync(headerData.settings?.darkMode);


  // --- RESCUE NOTIFICATION & DASHBOARD RESCUE ---
  useEffect(() => {
    if (typeof window !== 'undefined' && window.__ULTRA_RESCUE_SUCCESS) {
      showToast('Dados de "Direito" recuperados do armazenamento profundo! 💎📚', 'success');
      delete window.__ULTRA_RESCUE_SUCCESS;
    }

    // Reseta contador ao retornar para estado saudável
    if (isStoreHydrated && headerData.exists) {
      rescueAttemptsRef.current = 0;
    }

    let rescueTimer = null;
    let resetTimer = null;

    if (isStoreHydrated && !headerData.exists && rescueAttemptsRef.current < 3) {
      const keys = Object.keys(contestsMetaList || {});
      if (keys.length > 0) {
        console.warn('[Rescue] Concurso ativo inválido. Selecionando fallback:', keys[0]);
        rescueAttemptsRef.current += 1;
        
        rescueTimer = setTimeout(() => switchContest(keys[0]), 100);
        
        // Reset após 30s de estabilidade
        resetTimer = setTimeout(() => { 
          rescueAttemptsRef.current = 0; 
        }, 30000);
      }
    }

    return () => {
      if (rescueTimer) clearTimeout(rescueTimer);
      if (resetTimer) clearTimeout(resetTimer);
    };
  }, [showToast, isStoreHydrated, headerData.exists, contestsMetaList, switchContest]);

  const cloudStatusHeader = React.useMemo(() => ({
    status: cloudStatus,
    error: cloudError,
    syncing: isCloudSyncing,
    hasConflict,
    forcePull: forcePullCloud
  }), [cloudStatus, cloudError, isCloudSyncing, hasConflict, forcePullCloud]);

  useEffect(() => {
    return () => {
      if (importTimeoutRef.current) {
        clearTimeout(importTimeoutRef.current);
        importTimeoutRef.current = null;
      }
    };
  }, []);

  // Global Handlers
  const handleUndo = useCallback(() => {
    undo();
    showToast('Ação desfeita! ↩️', 'info');
  }, [undo, showToast]);

  const isMountedRef = useRef(true);
  useEffect(() => {
    isMountedRef.current = true;
    try {
      sessionStorage.removeItem('ultra_auto_reloaded');
    } catch { /* ignore */ }
    return () => { 
      isMountedRef.current = false; 
      stopCleanup();
    };
  }, []);

  const handleImport = useCallback((event) => {
    const file = event.target.files[0];
    if (!file) return;
    event.target.value = '';

    if (!Number.isFinite(file.size) || file.size > 50 * 1024 * 1024) { // 50MB
      showToast('O arquivo de backup é grande demais (máx 50MB).', 'error');
      return;
    }

    if (!file.type.includes('json') && !file.name.endsWith('.json')) {
      showToast('Formato de arquivo não suportado. Use um backup JSON.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      if (!isMountedRef.current) return;
      showToast('A processar backup... ⏳', 'info');

      // Joga o processamento pesado para o final da fila de eventos, 
      // deixando a animação do Toast ocorrer fluida.
      if (importTimeoutRef.current) clearTimeout(importTimeoutRef.current);
      importTimeoutRef.current = setTimeout(() => {
        if (!isMountedRef.current) return;
        try {
          const currentAppState = useAppStore.getState().appState;
          const result = parseImportedData(e.target.result, currentAppState);
          if (!result || !result.data || typeof result.data !== 'object') {
            showToast('Backup inválido ou corrompido.', 'error');
            return;
          }
          // ✅ FIX: Validar estrutura mínima antes de aplicar
          const importedData = result.data;
          if (!importedData.contests || typeof importedData.contests !== 'object') {
            showToast('Backup sem estrutura de concursos. Verifique o arquivo.', 'error');
            return;
          }
          // ✅ FIX: Garantir que activeId aponta para um concurso existente
          const contestIds = Object.keys(importedData.contests);
          if (contestIds.length === 0) {
            showToast('Backup sem concursos.', 'error');
            return;
          }
          if (!importedData.activeId || !importedData.contests[importedData.activeId]) {
            importedData.activeId = contestIds[0];
          }
          // ✅ FIX: Validar que cada concurso tem estrutura mínima
          for (const [id, contest] of Object.entries(importedData.contests)) {
            if (!contest || typeof contest !== 'object') {
              showToast(`Concurso "${id}" inválido no backup.`, 'error');
              return;
            }
          }
          setAppState(importedData);
          showToast('Backup restaurado com sucesso! ✨', 'success');
        } catch (err) {
          console.error("Import Error:", err);
          showToast(`Erro no Backup: ${err.message}`, 'error');
        } finally {
          importTimeoutRef.current = null;
        }
      }, 350); // Delay de 350ms permite que a animação de entrada do Toast complete suavemente
    };

    // FIX: Adicionar handler de erro no FileReader
    reader.onerror = () => {
      showToast('Erro ao ler arquivo.', 'error');
    };

    reader.readAsText(file);
  }, [setAppState, showToast]);

  const handleExport = useCallback(() => {
    exportData(useAppStore.getState().appState);
    showToast('Backup exportado!', 'success');
  }, [showToast]);

  const handleCloudRestore = useCallback((d) => {
    if (d) {
      setAppState(d);
      showToast('Restaurado da Nuvem!', 'success');
    }
  }, [setAppState, showToast]);

  // BUG-06 FIX: Removed useless useMemo. It used location.pathname as dep,
  // so it re-created on every navigation — exactly when Routes re-renders anyway.
  const routesContent = (
    <div className="animate-page-entrance">
      <ErrorBoundary>
        <Suspense fallback={
          <div className="flex items-center justify-center p-20 text-purple-400">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
          </div>
        }>
          <Routes>
            <Route path="/" element={<RootRedirect />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/pomodoro" element={<Pomodoro />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/simulados" element={<Simulados />} />
            <Route path="/stats" element={<Stats />} />
            <Route path="/evolution" element={<Evolution />} />
            <Route path="/coach" element={<Coach />} />
            <Route path="/history" element={<History />} />
            <Route path="/sessions" element={<Sessions />} />
            <Route path="/heatmap" element={<Activity />} />
            <Route path="/retention" element={<Retention />} />
            <Route path="/notes" element={<Notes />} />
            <Route path="/flashcards" element={<Flashcards />} />
            <Route path="/agenda" element={<Agenda />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </ErrorBoundary>
    </div>
  );


  // ── Render Logic ──
  if (!isStoreHydrated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#020617] gap-6 animate-fade-in">
        <div className="relative">
          <div className="w-20 h-20 border-4 border-indigo-500/10 border-t-indigo-500 rounded-full animate-spin" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 bg-indigo-500/20 rounded-full animate-pulse" />
          </div>
        </div>
        <div className="flex flex-col items-center gap-2">
          <span className="text-white font-black uppercase tracking-[0.3em] text-sm animate-pulse">Método Arraia</span>
          <span className="text-slate-500 text-[10px] uppercase font-bold tracking-widest">Iniciando Motor de Persistência...</span>
        </div>
      </div>
    );
  }

  // Welcome Screen bloqueante logo após o carregamento inicial (se não tiver sido mostrada nesta sessão)
  if (currentUser && showWelcome) {
    return <WelcomeScreen onDismiss={handleDismissWelcome} />;
  }

  return (
    <div suppressHydrationWarning className="min-h-screen text-slate-200 font-sans selection:bg-purple-500/30 relative overflow-x-hidden w-full">
      {(loading || subLoading) ? (
        <div className="flex items-center justify-center p-20 text-purple-400 min-h-screen bg-[#0f172a] animate-fade-in">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
        </div>
      ) : !currentUser ? (
        <Login />
      ) : !headerData.exists ? (
        <div className="loading-screen">Carregando Store...</div>
      ) : (
        <>
          {!isPremium ? (
            <div className="fixed inset-0 z-[99999] bg-[#0a0f1e] animate-fade-in">
              <Suspense fallback={null}>
                <Paywall user={currentUser} onLogout={logout} />
              </Suspense>
            </div>
          ) : (
            <div className="flex flex-col lg:grid lg:grid-cols-[auto_1fr] w-full h-dvh overflow-hidden animate-page-entrance">
              <Sidebar
                onOpenHelp={handleOpenHelp}
                isOpen={isSidebarOpen}
                onToggle={handleToggleSidebar}
                collapsed={sidebarCollapsed}
                setCollapsed={setSidebarCollapsed}
                contests={contestsMetaList}
                activeContestId={activeContestId}
                onSwitchContest={switchContest}
                onCreateContest={createNewContest}
                onDeleteContest={deleteContest}
                onOpenTrash={handleOpenTrash}
                onCloseMobile={handleCloseMobile}
                onExport={handleExport}
                onImport={handleImport}
              />

              <div className="flex flex-col h-dvh w-full min-w-0 relative">
                <Header
                  user={headerData.user}
                  settings={headerData.settings}
                  contests={contestsMetaList}
                  activeContestId={activeContestId}
                  onSwitchContest={switchContest}
                  onCreateContest={createNewContest}
                  onDeleteContest={deleteContest}
                  onUndo={handleUndo}
                  onCloudRestore={handleCloudRestore}
                  onUpdateName={updateUserName}
                  currentData={EMPTY_OBJECT}
                  cloudStatus={cloudStatusHeader}
                  onExport={handleExport}
                  onImport={handleImport}

                  onToggleSidebar={handleToggleSidebar}
                  sidebarCollapsed={sidebarCollapsed}
                  setSidebarCollapsed={setSidebarCollapsed}
                  onOpenTrash={handleOpenTrash}
                />

                <TrashModal isOpen={trashOpen} onClose={handleCloseTrash} />

                <main className="flex-1 w-full px-4 sm:px-8 lg:px-10 mt-0 pt-[110px] lg:pt-0 pb-24 lg:pb-12 overflow-y-auto overflow-x-hidden custom-scrollbar relative z-0">
                  <Motion.div 
                    key={`${activeContestId}-${location.pathname}`} 
                    initial={{ opacity: 0.9 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.2, ease: "easeOut" }}
                    style={{ transform: "none", filter: "none", willChange: "auto" }}
                  >
                    {routesContent}
                  </Motion.div>
                </main>
                <HelpGuide isOpen={showHelpGuide} onClose={handleCloseHelp} />
                <OnboardingTour />
              </div>
            </div>
          )}

          {levelUpData && (
            <LevelUpToast
              key={levelUpData.level}
              level={levelUpData.level}
              title={levelUpData.title}
              onClose={clearLevelUp}
            />
          )}

          {/* Global Event Driven Toast Container */}
          <div className="fixed bottom-4 right-4 z-[100000] flex flex-col gap-2 pointer-events-none">
            {toasts.map((toast) => (
              <div key={toast.id} className="pointer-events-auto">
                <Toast
                  toast={toast}
                  onClose={() => removeToast(toast.id)}
                />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function App() {
  return (
    <Router>
      <MainLayout />
    </Router>
  );
}

export default App;

