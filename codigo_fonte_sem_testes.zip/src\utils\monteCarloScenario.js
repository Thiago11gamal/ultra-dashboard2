// ✅ FIX: meanBiasFactor é PERCENTUAL da escala (0.025 = 2.5% do maxScore)
export const SCENARIO_CONFIG = {
  conservative: { meanBiasFactor: -0.015, ciMult: 1.5, probMultFactor: 0.045 },
  base:         { meanBiasFactor: 0,      ciMult: 1,   probMultFactor: 0 },
  optimistic:   { meanBiasFactor: 0.025,  ciMult: 0.85, probMultFactor: 0.045 },
};

export function applyScenarioAdjustments(data = [], scenario = 'base', maxScore = 100, minScore = 0) {
  const cfg = SCENARIO_CONFIG[scenario] || SCENARIO_CONFIG.base;
  const safeMaxScore = Number.isFinite(Number(maxScore)) && Number(maxScore) > 0 ? Number(maxScore) : 100;
  const safeMinScore = Number.isFinite(Number(minScore)) ? Number(minScore) : 0;
  const lowerBound = Math.min(safeMinScore, safeMaxScore);
  const upperBound = Math.max(safeMinScore, safeMaxScore);
  const meanBias = (cfg.meanBiasFactor || 0) * safeMaxScore;
  const probMult = (cfg.probMultFactor || 0) * 100;

  return (data || []).map((d) => {
    const mean = Math.max(lowerBound, Math.min(upperBound, (Number(d.mean) || 0) + meanBias));
    const projectedMean = d.projectedMean !== undefined
      ? Math.max(lowerBound, Math.min(upperBound, (Number(d.projectedMean) || 0) + meanBias))
      : mean;
    const low = Math.max(lowerBound, Math.min(upperBound, mean - ((mean - (d?.ciRange?.[0] ?? mean)) * cfg.ciMult)));
    const high = Math.max(lowerBound, Math.min(upperBound, mean + (((d?.ciRange?.[1] ?? mean) - mean) * cfg.ciMult)));
    const rawProb = Number(d?.probability);
    const probBase = Number.isFinite(rawProb) ? rawProb : 0;
    const probAdjRaw = probBase + (meanBias > 0 ? probMult : meanBias < 0 ? -probMult : 0);
    const probAdj = Number.isFinite(probAdjRaw) ? Math.max(0, Math.min(100, probAdjRaw)) : 0;
    return {
      ...d,
      mean,
      projectedMean,
      probability: Number.isFinite(probAdj) ? probAdj : 0,
      ciRange: [Math.min(low, high), Math.max(low, high)],
    };
  });
}

export function classifyScenarioSignal(data = [], maxScore = 100, minScore = 0) {
  if (!data.length) return null;
  const safeMaxScore = Number.isFinite(Number(maxScore)) && Number(maxScore) > 0 ? Number(maxScore) : 100;
  const safeMinScore = Number.isFinite(Number(minScore)) ? Number(minScore) : 0;
  const range = Math.max(1e-9, safeMaxScore - safeMinScore);
  const latest = data[data.length - 1];
  const high = Number(latest?.ciRange?.[1]);
  const low = Number(latest?.ciRange?.[0]);
  const width = Number.isFinite(high) && Number.isFinite(low) ? Math.max(0, high - low) : Number.POSITIVE_INFINITY;

  if (data.length < 4 || width >= (range * 0.18)) {
    return { label: 'Sinal Fraco', color: 'text-amber-300 border-amber-500/40 bg-amber-500/10' };
  }
  if (width <= (range * 0.10) && data.length >= 8) {
    return { label: 'Sinal Forte', color: 'text-emerald-300 border-emerald-500/40 bg-emerald-500/10' };
  }
  return { label: 'Sinal Médio', color: 'text-sky-300 border-sky-500/40 bg-sky-500/10' };
}
